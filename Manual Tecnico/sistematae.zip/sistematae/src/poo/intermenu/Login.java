package poo.intermenu;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.Timer;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

public class Login extends JFrame {

	private static final long serialVersionUID = 1L;

	private JPanel contentPane;
	private JPanel panelEncabezado;
	private JPanel panelPrincipal;
	private JLabel lblTitulo;
	private JLabel lblHora;
	private JLabel lblFecha;
	private JLabel lblUsuario;
	private JLabel lblContrasena;
	private JLabel lblLogo;
	private JTextField txtUsuario;
	private JPasswordField txtContrasena;
	private JButton btnIniciarSesion;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Login frame = new Login();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Login() {
		setTitle("Iniciar sesión");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 920, 600);
		setLocationRelativeTo(null);

		contentPane = new JPanel();
		contentPane.setBackground(new Color(243, 247, 251));
		contentPane.setLayout(null);
		setContentPane(contentPane);

		panelEncabezado = new JPanel();
		panelEncabezado.setBackground(Color.WHITE);
		panelEncabezado.setBorder(new LineBorder(new Color(218, 228, 239), 1, true));
		panelEncabezado.setBounds(18, 16, 868, 82);
		panelEncabezado.setLayout(null);
		contentPane.add(panelEncabezado);

		JLabel logoEncabezado = new JLabel(Imagenes.cargar("logo.jpeg", 60, 60));
		logoEncabezado.setBounds(20, 11, 60, 60);
		panelEncabezado.add(logoEncabezado);

		lblTitulo = new JLabel("TAE KWON DO MARCIAL DE MÉXICO A. C.");
		lblTitulo.setForeground(new Color(28, 59, 91));
		lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 17));
		lblTitulo.setBounds(96, 24, 570, 34);
		panelEncabezado.add(lblTitulo);

		lblHora = new JLabel("");
		lblHora.setHorizontalAlignment(SwingConstants.RIGHT);
		lblHora.setForeground(new Color(28, 59, 91));
		lblHora.setFont(new Font("Segoe UI", Font.BOLD, 13));
		lblHora.setBounds(696, 18, 145, 22);
		panelEncabezado.add(lblHora);

		lblFecha = new JLabel("");
		lblFecha.setHorizontalAlignment(SwingConstants.RIGHT);
		lblFecha.setForeground(new Color(100, 116, 139));
		lblFecha.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblFecha.setBounds(696, 43, 145, 22);
		panelEncabezado.add(lblFecha);

		panelPrincipal = new JPanel();
		panelPrincipal.setBackground(Color.WHITE);
		panelPrincipal.setBorder(new LineBorder(new Color(218, 228, 239), 1, true));
		panelPrincipal.setBounds(18, 112, 868, 426);
		panelPrincipal.setLayout(null);
		contentPane.add(panelPrincipal);

		lblLogo = new JLabel("");
		lblLogo.setHorizontalAlignment(SwingConstants.CENTER);
		lblLogo.setBounds(88, 72, 250, 200);
		cargarLogo("logo.jpeg");
		panelPrincipal.add(lblLogo);

		JLabel lblBienvenida = new JLabel("Bienvenido");
		lblBienvenida.setHorizontalAlignment(SwingConstants.CENTER);
		lblBienvenida.setForeground(new Color(28, 59, 91));
		lblBienvenida.setFont(new Font("Segoe UI", Font.BOLD, 18));
		lblBienvenida.setBounds(52, 292, 322, 32);
		panelPrincipal.add(lblBienvenida);

		JLabel lblAcceso = new JLabel("Iniciar sesión");
		lblAcceso.setForeground(new Color(28, 59, 91));
		lblAcceso.setFont(new Font("Segoe UI", Font.BOLD, 23));
		lblAcceso.setBounds(435, 74, 325, 36);
		panelPrincipal.add(lblAcceso);

		lblUsuario = new JLabel("Usuario");
		lblUsuario.setForeground(new Color(47, 65, 85));
		lblUsuario.setFont(new Font("Segoe UI", Font.BOLD, 14));
		lblUsuario.setBounds(435, 141, 325, 26);
		panelPrincipal.add(lblUsuario);

		txtUsuario = new JTextField();
		txtUsuario.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		txtUsuario.setBorder(new javax.swing.border.CompoundBorder(
				new LineBorder(new Color(196, 210, 225), 1, true),
				new EmptyBorder(0, 12, 0, 12)));
		txtUsuario.setBounds(435, 170, 334, 42);
		panelPrincipal.add(txtUsuario);

		lblContrasena = new JLabel("Contraseña");
		lblContrasena.setForeground(new Color(47, 65, 85));
		lblContrasena.setFont(new Font("Segoe UI", Font.BOLD, 14));
		lblContrasena.setBounds(435, 230, 325, 26);
		panelPrincipal.add(lblContrasena);

		txtContrasena = new JPasswordField();
		txtContrasena.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		txtContrasena.setBorder(new javax.swing.border.CompoundBorder(
				new LineBorder(new Color(196, 210, 225), 1, true),
				new EmptyBorder(0, 12, 0, 12)));
		txtContrasena.setBounds(435, 259, 334, 42);
		panelPrincipal.add(txtContrasena);

		btnIniciarSesion = new JButton("Iniciar sesión");
		btnIniciarSesion.setFont(new Font("Segoe UI", Font.BOLD, 14));
		btnIniciarSesion.setBackground(new Color(31, 104, 160));
		btnIniciarSesion.setForeground(Color.WHITE);
		btnIniciarSesion.setFocusPainted(false);
		btnIniciarSesion.setBorder(new LineBorder(new Color(31, 104, 160), 1, true));
		btnIniciarSesion.setBounds(583, 326, 186, 44);
		btnIniciarSesion.addActionListener(e -> iniciarSesion());
		panelPrincipal.add(btnIniciarSesion);

		getRootPane().setDefaultButton(btnIniciarSesion);

		iniciarReloj();
		Escalador.activar(this, contentPane);
	}

	private void cargarLogo(String archivo) {
		ImageIcon icono = Imagenes.cargar(archivo, 220, 190);
		if (icono != null) {
			lblLogo.setText("");
			lblLogo.setIcon(icono);
		}
	}
	private void iniciarReloj() {
		final SimpleDateFormat fmtHora = new SimpleDateFormat("hh:mm a", new Locale("es", "MX"));
		final SimpleDateFormat fmtFecha = new SimpleDateFormat("dd/MM/yyyy");
		Timer timer = new Timer(1000, e -> {
			Date ahora = new Date();
			lblHora.setText(fmtHora.format(ahora));
			lblFecha.setText(fmtFecha.format(ahora));
		});
		timer.setInitialDelay(0);
		timer.start();
	}
	private void iniciarSesion() {
		String usuario = txtUsuario.getText().trim();
		String contrasena = new String(txtContrasena.getPassword());

		if (usuario.isEmpty() || contrasena.isEmpty()) {
			JOptionPane.showMessageDialog(this, "Escribe tu usuario y contraseña.",
					"Campos vacíos", JOptionPane.WARNING_MESSAGE);
			return;
		}

		String sql = "SELECT id_secretaria, nombre FROM Secretaria "
				+ "WHERE correo = ? AND contrasena = SHA2(?, 256)";

		try (Connection con = Conexion.getConexion();
				PreparedStatement ps = con.prepareStatement(sql)) {

			ps.setString(1, usuario);
			ps.setString(2, contrasena);

			try (ResultSet rs = ps.executeQuery()) {
				if (rs.next()) {
					Sesion.idSecretaria = rs.getInt("id_secretaria");
					Sesion.nombreSecretaria = rs.getString("nombre");

					new Menuprincipal().setVisible(true);
					dispose();

				} else {
					JOptionPane.showMessageDialog(this, "Usuario o contraseña incorrectos.",
							"Error", JOptionPane.ERROR_MESSAGE);
					txtContrasena.setText("");
					txtContrasena.requestFocus();
				}
			}

		} catch (SQLException ex) {
			JOptionPane.showMessageDialog(this,
					"No se pudo conectar a la base de datos:\n" + ex.getMessage(),
					"Error de conexión", JOptionPane.ERROR_MESSAGE);
			ex.printStackTrace();
		}
	}
}