package poo.intermenu;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridLayout;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.YearMonth;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.CompoundBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

public class RegistroVentas extends JFrame {

    private static final long serialVersionUID = 1L;
    private static class ProductoItem {
        final int id;
        final String nombre;
        final BigDecimal precio;

        ProductoItem(int id, String nombre, BigDecimal precio) {
            this.id = id;
            this.nombre = nombre;
            this.precio = precio;
        }

        @Override
        public String toString() {
            return nombre;
        }
    }

    private JPanel contentPane;
    private JTextField txtCantidad;
    private JTextField txtPrecio;
    private JTextField txtTotal;
    private JTextField txtFecha;
    private JComboBox<String> cmbMes;
    private JTextField txtAño;
    private boolean sincronizando = false;
    private JTextField txtCliente;
    private JComboBox<ProductoItem> comboProducto;
    private JButton btnAceptar;
    private JButton btnCancelar;
    private JButton btnExportar;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    RegistroVentas frame = new RegistroVentas();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public RegistroVentas() {

        setTitle("Registro de ventas");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 920, 600);
        setLocationRelativeTo(null);
        setResizable(true);

        contentPane = new JPanel();
        contentPane.setBackground(new Color(243, 247, 251));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JPanel panelEncabezado = new JPanel(null);
        panelEncabezado.setBackground(Color.WHITE);
        panelEncabezado.setBorder(new LineBorder(new Color(218, 228, 239), 1, true));
        panelEncabezado.setBounds(18, 16, 868, 82);
        contentPane.add(panelEncabezado);

        JLabel lblLogo = new JLabel(Imagenes.cargar("logo.jpeg", 60, 60));
        lblLogo.setBounds(20, 11, 60, 60);
        panelEncabezado.add(lblLogo);

        JLabel lblTitulo = new JLabel("Registro de ventas");
        lblTitulo.setForeground(new Color(28, 59, 91));
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 19));
        lblTitulo.setBounds(96, 24, 380, 34);
        panelEncabezado.add(lblTitulo);

        JLabel lblSecretaria = new JLabel("Secretaria");
        lblSecretaria.setForeground(new Color(47, 65, 85));
        lblSecretaria.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblSecretaria.setBounds(686, 26, 95, 29);
        panelEncabezado.add(lblSecretaria);

        JLabel lblUsuario = new JLabel(Imagenes.cargar("usuario.png", 46, 46));
        lblUsuario.setBounds(790, 17, 52, 52);
        panelEncabezado.add(lblUsuario);

        JPanel panelPrincipal = new JPanel(null);
        panelPrincipal.setBackground(Color.WHITE);
        panelPrincipal.setBorder(new LineBorder(new Color(218, 228, 239), 1, true));
        panelPrincipal.setBounds(18, 112, 868, 426);
        contentPane.add(panelPrincipal);

        JLabel lblDatos = new JLabel("Datos de la venta");
        lblDatos.setForeground(new Color(28, 59, 91));
        lblDatos.setFont(new Font("Segoe UI", Font.BOLD, 21));
        lblDatos.setBounds(42, 25, 350, 34);
        panelPrincipal.add(lblDatos);

        JLabel lblCliente = new JLabel("Cliente:");
        lblCliente.setForeground(new Color(47, 65, 85));
        lblCliente.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblCliente.setBounds(63, 82, 123, 33);
        panelPrincipal.add(lblCliente);

        txtCliente = new JTextField();
        txtCliente.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtCliente.setBorder(new CompoundBorder(new LineBorder(new Color(196, 210, 225), 1, true),
                new EmptyBorder(0, 12, 0, 12)));
        txtCliente.setBounds(200, 80, 616, 39);
        panelPrincipal.add(txtCliente);
        txtCliente.setColumns(10);

        JLabel lblProducto = new JLabel("Producto:");
        lblProducto.setForeground(new Color(47, 65, 85));
        lblProducto.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblProducto.setBounds(63, 136, 123, 33);
        panelPrincipal.add(lblProducto);

        comboProducto = new JComboBox<ProductoItem>();
        comboProducto.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        comboProducto.setBackground(Color.WHITE);
        comboProducto.setBorder(new LineBorder(new Color(196, 210, 225), 1, true));
        comboProducto.setBounds(200, 134, 616, 39);
        panelPrincipal.add(comboProducto);

        JLabel lblPrecio = new JLabel("Precio unitario:");
        lblPrecio.setForeground(new Color(47, 65, 85));
        lblPrecio.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblPrecio.setBounds(63, 191, 133, 33);
        panelPrincipal.add(lblPrecio);

        txtPrecio = new JTextField();
        txtPrecio.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtPrecio.setForeground(new Color(47, 65, 85));
        txtPrecio.setBackground(new Color(243, 247, 251));
        txtPrecio.setBorder(new CompoundBorder(new LineBorder(new Color(196, 210, 225), 1, true),
                new EmptyBorder(0, 12, 0, 12)));
        txtPrecio.setBounds(200, 188, 180, 39);
        txtPrecio.setEditable(false);
        panelPrincipal.add(txtPrecio);
        txtPrecio.setColumns(10);

        JLabel lblCantidad = new JLabel("Cantidad:");
        lblCantidad.setForeground(new Color(47, 65, 85));
        lblCantidad.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblCantidad.setBounds(464, 191, 106, 33);
        panelPrincipal.add(lblCantidad);

        txtCantidad = new JTextField();
        txtCantidad.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtCantidad.setBorder(new CompoundBorder(new LineBorder(new Color(196, 210, 225), 1, true),
                new EmptyBorder(0, 12, 0, 12)));
        txtCantidad.setBounds(578, 188, 238, 39);
        panelPrincipal.add(txtCantidad);
        txtCantidad.setColumns(10);

        JLabel lblTotal = new JLabel("Total:");
        lblTotal.setForeground(new Color(47, 65, 85));
        lblTotal.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblTotal.setBounds(63, 245, 120, 33);
        panelPrincipal.add(lblTotal);

        txtTotal = new JTextField();
        txtTotal.setFont(new Font("Segoe UI", Font.BOLD, 15));
        txtTotal.setForeground(new Color(31, 104, 160));
        txtTotal.setBackground(new Color(243, 247, 251));
        txtTotal.setBorder(new CompoundBorder(new LineBorder(new Color(196, 210, 225), 1, true),
                new EmptyBorder(0, 12, 0, 12)));
        txtTotal.setBounds(200, 242, 180, 39);
        txtTotal.setEditable(false);
        panelPrincipal.add(txtTotal);
        txtTotal.setColumns(10);

        JLabel lblFecha = new JLabel("Fecha:");
        lblFecha.setForeground(new Color(47, 65, 85));
        lblFecha.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblFecha.setBounds(63, 299, 125, 33);
        panelPrincipal.add(lblFecha);

        txtFecha = new JTextField();
        txtFecha.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtFecha.setBorder(new CompoundBorder(new LineBorder(new Color(196, 210, 225), 1, true),
                new EmptyBorder(0, 12, 0, 12)));
        txtFecha.setBounds(200, 296, 156, 39);
        txtFecha.setText(LocalDate.now().format(FORMATO));
        panelPrincipal.add(txtFecha);

        JButton btnHoy = new JButton("Hoy");
        btnHoy.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnHoy.setForeground(new Color(31, 104, 160));
        btnHoy.setBackground(new Color(235, 244, 251));
        btnHoy.setBorder(new LineBorder(new Color(196, 210, 225), 1, true));
        btnHoy.setFocusPainted(false);
        btnHoy.setBounds(365, 296, 60, 39);
        btnHoy.setToolTipText("Colocar fecha actual");
        panelPrincipal.add(btnHoy);

        JLabel lblMes = new JLabel("Mes:");
        lblMes.setForeground(new Color(47, 65, 85));
        lblMes.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblMes.setBounds(442, 299, 43, 33);
        panelPrincipal.add(lblMes);

        cmbMes = new JComboBox<>(MESES);
        cmbMes.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        cmbMes.setBackground(Color.WHITE);
        cmbMes.setBorder(new LineBorder(new Color(196, 210, 225), 1, true));
        cmbMes.setBounds(486, 296, 150, 39);
        cmbMes.setSelectedIndex(LocalDate.now().getMonthValue() - 1);
        panelPrincipal.add(cmbMes);

        JLabel lblAño = new JLabel("Año:");
        lblAño.setForeground(new Color(47, 65, 85));
        lblAño.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblAño.setBounds(650, 299, 47, 33);
        panelPrincipal.add(lblAño);

        txtAño = new JTextField();
        txtAño.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtAño.setBorder(new CompoundBorder(new LineBorder(new Color(196, 210, 225), 1, true),
                new EmptyBorder(0, 12, 0, 12)));
        txtAño.setBounds(699, 296, 117, 39);
        txtAño.setText(String.valueOf(LocalDate.now().getYear()));
        panelPrincipal.add(txtAño);

        btnAceptar = new JButton("Registrar venta");
        btnAceptar.setForeground(Color.WHITE);
        btnAceptar.setBackground(new Color(31, 104, 160));
        btnAceptar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnAceptar.setFocusPainted(false);
        btnAceptar.setBorder(new LineBorder(new Color(31, 104, 160), 1, true));
        btnAceptar.setBounds(495, 358, 156, 43);
        panelPrincipal.add(btnAceptar);

        btnCancelar = new JButton("Cancelar");
        btnCancelar.setForeground(new Color(31, 104, 160));
        btnCancelar.setBackground(new Color(235, 244, 251));
        btnCancelar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnCancelar.setFocusPainted(false);
        btnCancelar.setBorder(new LineBorder(new Color(196, 210, 225), 1, true));
        btnCancelar.setBounds(663, 358, 153, 43);
        panelPrincipal.add(btnCancelar);

        btnExportar = new JButton("Guardar ventas del mes");
        btnExportar.setForeground(new Color(31, 104, 160));
        btnExportar.setBackground(new Color(235, 244, 251));
        btnExportar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnExportar.setFocusPainted(false);
        btnExportar.setBorder(new LineBorder(new Color(196, 210, 225), 1, true));
        btnExportar.setBounds(63, 358, 215, 43);
        panelPrincipal.add(btnExportar);

        cargarProductos();
        actualizarPrecio();

        btnExportar.addActionListener(e -> exportarVentas());

        btnHoy.addActionListener(e -> txtFecha.setText(LocalDate.now().format(FORMATO)));

        txtFecha.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) { fechaACampos(); }

            @Override
            public void removeUpdate(DocumentEvent e) { fechaACampos(); }

            @Override
            public void changedUpdate(DocumentEvent e) { fechaACampos(); }
        });

        cmbMes.addActionListener(e -> camposAFecha());

        txtAño.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) { camposAFecha(); }

            @Override
            public void removeUpdate(DocumentEvent e) { camposAFecha(); }

            @Override
            public void changedUpdate(DocumentEvent e) { camposAFecha(); }
        });

        comboProducto.addActionListener(e -> {
            actualizarPrecio();
            calcularTotal();
        });

        txtCantidad.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) { calcularTotal(); }

            @Override
            public void removeUpdate(DocumentEvent e) { calcularTotal(); }

            @Override
            public void changedUpdate(DocumentEvent e) { calcularTotal(); }
        });

        btnAceptar.addActionListener(e -> registrarVenta());

        btnCancelar.addActionListener(e -> {
            txtFecha.setText(LocalDate.now().format(FORMATO));
            txtCliente.setText("");
            txtCantidad.setText("");
            txtTotal.setText("");
            if (comboProducto.getItemCount() > 0) {
                comboProducto.setSelectedIndex(0);
            }
            actualizarPrecio();
        });

        Escalador.activar(this, contentPane);
    }
    private void cargarProductos() {
        List<ProductoItem> lista = new ArrayList<>();
        String sql = "SELECT id_producto, nombre, precio FROM Producto ORDER BY nombre";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(new ProductoItem(rs.getInt("id_producto"),
                        rs.getString("nombre"), rs.getBigDecimal("precio")));
            }

        } catch (SQLException ex) {
            errorBD("No se pudieron cargar los productos", ex);
        }

        for (ProductoItem p : lista) {
            comboProducto.addItem(p);
        }
    }
    private static final DateTimeFormatter FORMATO =
            DateTimeFormatter.ofPattern("dd/MM/uuuu").withResolverStyle(ResolverStyle.STRICT);

    private static final String[] MESES = {"Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
            "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"};

    private LocalDate leerFecha(String texto) {
        try {
            return LocalDate.parse(texto.trim(), FORMATO);
        } catch (DateTimeParseException ex) {
            return null;
        }
    }

    private void fechaACampos() {
        if (sincronizando) {
            return;
        }
        LocalDate fecha = leerFecha(txtFecha.getText());
        if (fecha == null) {
            return;
        }
        sincronizando = true;
        cmbMes.setSelectedIndex(fecha.getMonthValue() - 1);
        txtAño.setText(String.valueOf(fecha.getYear()));
        sincronizando = false;
    }

    private void camposAFecha() {
        if (sincronizando) {
            return;
        }
        int año;
        try {
            año = Integer.parseInt(txtAño.getText().trim());
        } catch (NumberFormatException ex) {
            return;
        }
        if (año < 2000 || año > 2100) {
            return;
        }
        LocalDate actual = leerFecha(txtFecha.getText());
        int dia = actual == null ? LocalDate.now().getDayOfMonth() : actual.getDayOfMonth();
        int mes = cmbMes.getSelectedIndex() + 1;
        int ultimoDia = YearMonth.of(año, mes).lengthOfMonth();
        sincronizando = true;
        txtFecha.setText(LocalDate.of(año, mes, Math.min(dia, ultimoDia)).format(FORMATO));
        sincronizando = false;
    }

    private int obtenerIdCliente(Connection con, String nombre) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(
                "SELECT id_cliente FROM Cliente WHERE nombre = ? LIMIT 1")) {
            ps.setString(1, nombre);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1);
                }
            }
        }
        try (PreparedStatement ps = con.prepareStatement(
                "INSERT INTO Cliente (nombre) VALUES (?)", Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, nombre);
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                rs.next();
                return rs.getInt(1);
            }
        }
    }

    private int[] pedirMesYAño() {
        JComboBox<String> cmbMesArchivo = new JComboBox<>(MESES);
        cmbMesArchivo.setSelectedIndex(LocalDate.now().getMonthValue() - 1);
        JTextField txtAñoArchivo = new JTextField(String.valueOf(LocalDate.now().getYear()));

        JPanel panel = new JPanel(new GridLayout(2, 2, 8, 8));
        panel.add(new JLabel("Mes:"));
        panel.add(cmbMesArchivo);
        panel.add(new JLabel("Año:"));
        panel.add(txtAñoArchivo);

        int respuesta = JOptionPane.showConfirmDialog(this, panel,
                "¿De qué mes quieres guardar las ventas?",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (respuesta != JOptionPane.OK_OPTION) {
            return null;
        }

        try {
            int año = Integer.parseInt(txtAñoArchivo.getText().trim());
            if (año < 2000 || año > 2100) {
                throw new NumberFormatException();
            }
            return new int[] {cmbMesArchivo.getSelectedIndex() + 1, año};
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Escribe un año válido (por ejemplo 2026).",
                    "Año incorrecto", JOptionPane.WARNING_MESSAGE);
            return null;
        }
    }

    private void exportarVentas() {
        int[] periodo = pedirMesYAño();
        if (periodo == null) {
            return;
        }
        int mes = periodo[0];
        int año = periodo[1];
        String nombreMes = MESES[mes - 1];

        String sql = "SELECT c.no_venta, c.fecha, cl.nombre AS cliente, p.nombre AS producto, "
                + "cp.cantidad, p.precio "
                + "FROM Compra c "
                + "JOIN Cliente cl ON cl.id_cliente = c.id_cliente "
                + "JOIN Compra_producto cp ON cp.no_venta = c.no_venta "
                + "JOIN Producto p ON p.id_producto = cp.id_producto "
                + "WHERE MONTH(c.fecha) = ? AND YEAR(c.fecha) = ? "
                + "ORDER BY c.fecha, c.no_venta";

        List<String[]> filas = new ArrayList<>();
        BigDecimal totalMes = BigDecimal.ZERO;

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, mes);
            ps.setInt(2, año);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    BigDecimal precio = rs.getBigDecimal("precio");
                    int cantidad = rs.getInt("cantidad");
                    BigDecimal subtotal = precio.multiply(BigDecimal.valueOf(cantidad))
                            .setScale(2, java.math.RoundingMode.HALF_UP);
                    totalMes = totalMes.add(subtotal);

                    filas.add(new String[] {
                        String.valueOf(rs.getInt("no_venta")),
                        rs.getTimestamp("fecha").toLocalDateTime()
                                .format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm")),
                        rs.getString("cliente"),
                        rs.getString("producto"),
                        String.valueOf(cantidad),
                        precio.toPlainString(),
                        subtotal.toPlainString()
                    });
                }
            }

        } catch (SQLException ex) {
            errorBD("No se pudieron leer las ventas", ex);
            return;
        }

        if (filas.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "No hay ventas registradas en " + nombreMes + " " + año + ".",
                    "Sin ventas", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        JFileChooser selector = new JFileChooser();
        selector.setDialogTitle("Guardar ventas de " + nombreMes + " " + año);
        selector.setFileFilter(new FileNameExtensionFilter("Archivo para Excel (*.csv)", "csv"));
        selector.setSelectedFile(new File("ventas_" + nombreMes.toLowerCase() + "_" + año + ".csv"));
        if (selector.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) {
            return;
        }

        File archivo = selector.getSelectedFile();
        if (!archivo.getName().toLowerCase().endsWith(".csv")) {
            archivo = new File(archivo.getParentFile(), archivo.getName() + ".csv");
        }
        if (archivo.exists()) {
            int sobrescribir = JOptionPane.showConfirmDialog(this,
                    "El archivo ya existe. ¿Deseas reemplazarlo?",
                    "Archivo existente", JOptionPane.YES_NO_OPTION);
            if (sobrescribir != JOptionPane.YES_OPTION) {
                return;
            }
        }

        try (PrintWriter pw = new PrintWriter(
                new OutputStreamWriter(new FileOutputStream(archivo), StandardCharsets.UTF_8))) {

            pw.write('﻿');
            pw.println("Ventas de " + nombreMes + " " + año);
            pw.println("No. venta,Fecha,Cliente,Producto,Cantidad,Precio unitario,Subtotal");
            for (String[] f : filas) {
                StringBuilder linea = new StringBuilder();
                for (int i = 0; i < f.length; i++) {
                    if (i > 0) {
                        linea.append(',');
                    }
                    linea.append(csv(f[i]));
                }
                pw.println(linea);
            }
            pw.println(",,,,,TOTAL DEL MES," + totalMes.toPlainString());

            if (pw.checkError()) {
                throw new IOException("Error al escribir el archivo");
            }

        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this,
                    "No se pudo guardar el archivo:\n" + ex.getMessage(),
                    "Error al guardar", JOptionPane.ERROR_MESSAGE);
            return;
        }

        JOptionPane.showMessageDialog(this,
                "Ventas de " + nombreMes + " " + año + " guardadas en:\n" + archivo.getAbsolutePath(),
                "Archivo guardado", JOptionPane.INFORMATION_MESSAGE);
    }

    private String csv(String valor) {
        if (valor == null) {
            return "";
        }
        if (valor.contains(",") || valor.contains("\"") || valor.contains("\n")) {
            return "\"" + valor.replace("\"", "\"\"") + "\"";
        }
        return valor;
    }

    private void errorBD(String titulo, SQLException ex) {
        JOptionPane.showMessageDialog(this,
                titulo + ":\n" + ex.getMessage(),
                "Error de base de datos", JOptionPane.ERROR_MESSAGE);
    }
   private void actualizarPrecio() {
        ProductoItem p = (ProductoItem) comboProducto.getSelectedItem();
        txtPrecio.setText(p == null ? "" : "$" + p.precio.toPlainString());
    }
    private void calcularTotal() {
        ProductoItem p = (ProductoItem) comboProducto.getSelectedItem();
        if (p == null) {
            txtTotal.setText("");
            return;
        }
        try {
            int cantidad = Integer.parseInt(txtCantidad.getText().trim());
            if (cantidad > 0) {
                txtTotal.setText(p.precio.multiply(BigDecimal.valueOf(cantidad)).setScale(2).toPlainString());
            } else {
                txtTotal.setText("");
            }
        } catch (NumberFormatException e) {
            txtTotal.setText("");
        }
    }

    private void registrarVenta() {
        if (!Sesion.haySesion()) {
            JOptionPane.showMessageDialog(this,
                    "Inicia sesión desde el Login para poder registrar ventas.",
                    "Sin sesión", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String nombreCliente = txtCliente.getText().trim();
        if (nombreCliente.isEmpty() || nombreCliente.length() > 100) {
            JOptionPane.showMessageDialog(this,
                    "Escribe el nombre del cliente (máximo 100 caracteres).",
                    "Datos incorrectos", JOptionPane.WARNING_MESSAGE);
            txtCliente.requestFocus();
            return;
        }

        ProductoItem p = (ProductoItem) comboProducto.getSelectedItem();
        if (p == null) {
            JOptionPane.showMessageDialog(this,
                    "Faltan productos en la base de datos.",
                    "Sin datos", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int cantidad;
        try {
            cantidad = Integer.parseInt(txtCantidad.getText().trim());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Ingresa una cantidad entera válida.",
                    "Datos incorrectos", JOptionPane.WARNING_MESSAGE);
            txtCantidad.requestFocus();
            return;
        }
        if (cantidad <= 0 || cantidad > 1000) {
            JOptionPane.showMessageDialog(this, "La cantidad debe estar entre 1 y 1000.",
                    "Datos incorrectos", JOptionPane.WARNING_MESSAGE);
            txtCantidad.requestFocus();
            return;
        }

        LocalDate fecha = leerFecha(txtFecha.getText());
        if (fecha == null) {
            JOptionPane.showMessageDialog(this, "La fecha debe ser válida y usar dd/MM/aaaa.",
                    "Fecha incorrecta", JOptionPane.WARNING_MESSAGE);
            txtFecha.requestFocus();
            return;
        }

        BigDecimal total = p.precio.multiply(BigDecimal.valueOf(cantidad)).setScale(2);

        Connection con = null;
        try {
            con = Conexion.getConexion();
            con.setAutoCommit(false);

            int idCliente = obtenerIdCliente(con, nombreCliente);

            int noVenta;
            String sqlCompra = "INSERT INTO Compra (fecha, total, id_cliente, id_secretaria) VALUES (?, ?, ?, ?)";
            try (PreparedStatement ps = con.prepareStatement(sqlCompra, Statement.RETURN_GENERATED_KEYS)) {
                ps.setTimestamp(1, Timestamp.valueOf(fecha.atTime(LocalTime.now())));
                ps.setBigDecimal(2, total);
                ps.setInt(3, idCliente);
                ps.setInt(4, Sesion.idSecretaria);
                ps.executeUpdate();
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    rs.next();
                    noVenta = rs.getInt(1);
                }
            }

            String sqlDetalle = "INSERT INTO Compra_producto (no_venta, id_producto, cantidad) VALUES (?, ?, ?)";
            try (PreparedStatement ps = con.prepareStatement(sqlDetalle)) {
                ps.setInt(1, noVenta);
                ps.setInt(2, p.id);
                ps.setInt(3, cantidad);
                ps.executeUpdate();
            }

            con.commit();

            JOptionPane.showMessageDialog(this,
                    "Venta registrada correctamente.\n\n"
                    + "Venta No. " + noVenta
                    + "\nCliente: " + nombreCliente
                    + "\nProducto: " + p.nombre
                    + "\nCantidad: " + cantidad
                    + "\nPrecio unitario: $" + p.precio.toPlainString()
                    + "\nTotal: $" + total.toPlainString(),
                    "Registro de venta", JOptionPane.INFORMATION_MESSAGE);

            txtCliente.setText("");
            txtCantidad.setText("");
            txtTotal.setText("");
            txtFecha.setText(LocalDate.now().format(FORMATO));
            txtCliente.requestFocus();

        } catch (SQLException ex) {
            if (con != null) {
                try { con.rollback(); } catch (SQLException ignorar) { }
            }
            errorBD("No se pudo guardar la venta", ex);
        } finally {
            if (con != null) {
                try { con.close(); } catch (SQLException ignorar) { }
            }
        }
    }
}

