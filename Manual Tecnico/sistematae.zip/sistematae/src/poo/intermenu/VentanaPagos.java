package poo.intermenu;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.border.LineBorder;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.util.ArrayList;
import java.util.List;

public class VentanaPagos extends JFrame {

    private static final long serialVersionUID = 1L;

    private static class AlumnoItem {
        final int id;
        final String nombre;

        AlumnoItem(int id, String nombre) {
            this.id = id;
            this.nombre = nombre;
        }

        @Override
        public String toString() {
            return nombre;
        }
    }

    private JComboBox<AlumnoItem> cmbAlumno;
    private JComboBox<String> cmbMetodoPago;
    private JTextField txtMonto;
    private JTextField txtFecha;
    private JComboBox<String> cmbMes;
    private JTextField txtAño;

    private static final DateTimeFormatter FORMATO =
            DateTimeFormatter.ofPattern("dd/MM/uuuu").withResolverStyle(ResolverStyle.STRICT);

    private static final String[] METODOS = {"Efectivo", "Transferencia", "Tarjeta"};

    private static final String[] MESES = {"Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
            "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"};

    private static final BigDecimal MONTO_MAXIMO = new BigDecimal("999999.99");

    public VentanaPagos() {
        setTitle("Registro de pagos");
        setSize(920, 600);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(true);

        JPanel panel = new JPanel(null);
        panel.setBackground(new Color(243, 247, 251));
        getContentPane().add(panel);

        JPanel panelEncabezado = new JPanel(null);
        panelEncabezado.setBackground(Color.WHITE);
        panelEncabezado.setBorder(new LineBorder(new Color(218, 228, 239), 1, true));
        panelEncabezado.setBounds(18, 16, 868, 82);
        panel.add(panelEncabezado);

        JLabel lblLogoEscuela = new JLabel(Imagenes.cargar("logo.jpeg", 60, 60));
        lblLogoEscuela.setBounds(20, 11, 60, 60);
        panelEncabezado.add(lblLogoEscuela);

        JLabel lblTitulo = new JLabel("Registro de pagos");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 19));
        lblTitulo.setForeground(new Color(28, 59, 91));
        lblTitulo.setBounds(96, 24, 380, 34);
        panelEncabezado.add(lblTitulo);

        JLabel lblSecretaria = new JLabel("Secretaria");
        lblSecretaria.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblSecretaria.setForeground(new Color(47, 65, 85));
        lblSecretaria.setBounds(686, 26, 95, 29);
        panelEncabezado.add(lblSecretaria);

        JLabel lblUsuario = new JLabel(Imagenes.cargar("usuario.png", 46, 46));
        lblUsuario.setBounds(790, 17, 52, 52);
        panelEncabezado.add(lblUsuario);

        JPanel panelPrincipal = new JPanel(null);
        panelPrincipal.setBackground(Color.WHITE);
        panelPrincipal.setBorder(new LineBorder(new Color(218, 228, 239), 1, true));
        panelPrincipal.setBounds(18, 112, 868, 426);
        panel.add(panelPrincipal);

        JLabel lblDatos = new JLabel("Datos del pago");
        lblDatos.setFont(new Font("Segoe UI", Font.BOLD, 21));
        lblDatos.setForeground(new Color(28, 59, 91));
        lblDatos.setBounds(42, 25, 350, 34);
        panelPrincipal.add(lblDatos);

        LineBorder bordoCampos = new LineBorder(new Color(196, 210, 225), 1, true);
        Font fuenteEtiqueta = new Font("Segoe UI", Font.BOLD, 14);

        JLabel lblNombre = new JLabel("Alumno:");
        lblNombre.setFont(fuenteEtiqueta);
        lblNombre.setForeground(new Color(47, 65, 85));
        lblNombre.setBounds(63, 93, 125, 33);
        panelPrincipal.add(lblNombre);

        cmbAlumno = new JComboBox<>();
        cmbAlumno.setBounds(200, 91, 555, 39);
        cmbAlumno.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        cmbAlumno.setBackground(Color.WHITE);
        cmbAlumno.setBorder(bordoCampos);
        panelPrincipal.add(cmbAlumno);

        JButton btnBuscar = new JButton("Ver");
        btnBuscar.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnBuscar.setForeground(new Color(31, 104, 160));
        btnBuscar.setBackground(new Color(235, 244, 251));
        btnBuscar.setBorder(bordoCampos);
        btnBuscar.setBounds(767, 91, 49, 39);
        btnBuscar.setFocusPainted(false);
        btnBuscar.setToolTipText("Ver pagos anteriores de este alumno");
        btnBuscar.addActionListener(e -> {
            AlumnoItem a = (AlumnoItem) cmbAlumno.getSelectedItem();
            mostrarPagos(a == null ? null : a.id);
        });
        panelPrincipal.add(btnBuscar);

        JLabel lblMetodo = new JLabel("Método de pago:");
        lblMetodo.setFont(fuenteEtiqueta);
        lblMetodo.setForeground(new Color(47, 65, 85));
        lblMetodo.setBounds(63, 153, 133, 33);
        panelPrincipal.add(lblMetodo);

        cmbMetodoPago = new JComboBox<>(METODOS);
        cmbMetodoPago.setBounds(200, 151, 616, 39);
        cmbMetodoPago.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        cmbMetodoPago.setBackground(Color.WHITE);
        cmbMetodoPago.setBorder(bordoCampos);
        panelPrincipal.add(cmbMetodoPago);

        JLabel lblMonto = new JLabel("Monto:");
        lblMonto.setFont(fuenteEtiqueta);
        lblMonto.setForeground(new Color(47, 65, 85));
        lblMonto.setBounds(63, 215, 125, 33);
        panelPrincipal.add(lblMonto);

        txtMonto = new JTextField();
        txtMonto.setBounds(200, 212, 616, 39);
        txtMonto.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtMonto.setBorder(bordoCampos);
        txtMonto.setMargin(new Insets(2, 23, 2, 8));
        panelPrincipal.add(txtMonto);

        JLabel lblPesos = new JLabel("$");
        lblPesos.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblPesos.setForeground(new Color(31, 104, 160));
        lblPesos.setBounds(211, 212, 20, 39);
        panelPrincipal.add(lblPesos);
        panelPrincipal.setComponentZOrder(lblPesos, 0);

        JLabel lblFecha = new JLabel("Fecha:");
        lblFecha.setFont(fuenteEtiqueta);
        lblFecha.setForeground(new Color(47, 65, 85));
        lblFecha.setBounds(63, 277, 125, 33);
        panelPrincipal.add(lblFecha);

        txtFecha = new JTextField();
        txtFecha.setBounds(200, 274, 156, 39);
        txtFecha.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtFecha.setBorder(bordoCampos);
        txtFecha.setText(LocalDate.now().format(FORMATO));
        panelPrincipal.add(txtFecha);

        JButton btnCalendario = new JButton("Hoy");
        btnCalendario.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnCalendario.setForeground(new Color(31, 104, 160));
        btnCalendario.setBackground(new Color(235, 244, 251));
        btnCalendario.setBorder(bordoCampos);
        btnCalendario.setBounds(365, 274, 60, 39);
        btnCalendario.setFocusPainted(false);
        btnCalendario.setToolTipText("Colocar fecha actual");
        btnCalendario.addActionListener(e -> txtFecha.setText(LocalDate.now().format(FORMATO)));
        panelPrincipal.add(btnCalendario);

        JLabel lblMes = new JLabel("Mes:");
        lblMes.setFont(fuenteEtiqueta);
        lblMes.setForeground(new Color(47, 65, 85));
        lblMes.setBounds(442, 277, 43, 33);
        panelPrincipal.add(lblMes);

        cmbMes = new JComboBox<>(MESES);
        cmbMes.setBounds(486, 274, 150, 39);
        cmbMes.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        cmbMes.setBackground(Color.WHITE);
        cmbMes.setBorder(bordoCampos);
        cmbMes.setSelectedIndex(LocalDate.now().getMonthValue() - 1);
        panelPrincipal.add(cmbMes);

        JLabel lblAño = new JLabel("Año:");
        lblAño.setFont(fuenteEtiqueta);
        lblAño.setForeground(new Color(47, 65, 85));
        lblAño.setBounds(650, 277, 47, 33);
        panelPrincipal.add(lblAño);

        txtAño = new JTextField();
        txtAño.setBounds(699, 274, 117, 39);
        txtAño.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtAño.setBorder(bordoCampos);
        txtAño.setText(String.valueOf(LocalDate.now().getYear()));
        panelPrincipal.add(txtAño);

        JButton btnRegistrar = new JButton("Registrar");
        btnRegistrar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnRegistrar.setForeground(Color.WHITE);
        btnRegistrar.setBackground(new Color(31, 104, 160));
        btnRegistrar.setBorder(new LineBorder(new Color(31, 104, 160), 1, true));
        btnRegistrar.setFocusPainted(false);
        btnRegistrar.setBounds(435, 349, 121, 43);
        btnRegistrar.addActionListener(e -> registrarPago());
        panelPrincipal.add(btnRegistrar);

        JButton btnConsultar = new JButton("Ver pagos");
        btnConsultar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnConsultar.setForeground(new Color(31, 104, 160));
        btnConsultar.setBackground(new Color(235, 244, 251));
        btnConsultar.setBorder(bordoCampos);
        btnConsultar.setFocusPainted(false);
        btnConsultar.setBounds(568, 349, 121, 43);
        btnConsultar.addActionListener(e -> mostrarPagos());
        panelPrincipal.add(btnConsultar);

        JButton btnCancelar = new JButton("Cancelar");
        btnCancelar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnCancelar.setForeground(new Color(31, 104, 160));
        btnCancelar.setBackground(new Color(235, 244, 251));
        btnCancelar.setBorder(bordoCampos);
        btnCancelar.setFocusPainted(false);
        btnCancelar.setBounds(701, 349, 115, 43);
        btnCancelar.addActionListener(e -> limpiarCampos());
        panelPrincipal.add(btnCancelar);

        try {
            for (AlumnoItem a : cargarAlumnos()) {
                cmbAlumno.addItem(a);
            }
        } catch (SQLException ex) {
            errorBD("No se pudieron cargar los alumnos", ex);
        }

        Escalador.activar(this, panel);
    }
    private List<AlumnoItem> cargarAlumnos() throws SQLException {
        List<AlumnoItem> lista = new ArrayList<>();
        String sql = "SELECT id_alumno, nombre FROM Alumno ORDER BY nombre";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(new AlumnoItem(rs.getInt("id_alumno"), rs.getString("nombre")));
            }
        }
        return lista;
    }
    private List<Object[]> cargarPagos(Integer idAlumno) throws SQLException {
        List<Object[]> pagos = new ArrayList<>();
        String sql = "SELECT c.id_comprobante, c.id_alumno, c.mes, c.`año`, c.numero_comprobante, "
                + "a.nombre, c.metodo_pago, c.monto_total, c.fecha_pago "
                + "FROM Comprobante_pago c JOIN Alumno a ON a.id_alumno = c.id_alumno "
                + (idAlumno != null ? "WHERE c.id_alumno = ? " : "")
                + "ORDER BY c.fecha_pago DESC, c.id_comprobante DESC";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            if (idAlumno != null) {
                ps.setInt(1, idAlumno);
            }

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    int mes = rs.getInt("mes");
                    int año = rs.getInt("año");
                    pagos.add(new Object[] {
                        rs.getInt("id_comprobante"),
                        rs.getInt("id_alumno"),
                        mes,
                        año,
                        rs.getString("numero_comprobante"),
                        rs.getString("nombre"),
                        MESES[mes - 1] + " " + año,
                        rs.getString("metodo_pago"),
                        rs.getBigDecimal("monto_total").toPlainString(),
                        rs.getDate("fecha_pago").toLocalDate().format(FORMATO)
                    });
                }
            }
        }
        return pagos;
    }

    private void errorBD(String titulo, SQLException ex) {
        JOptionPane.showMessageDialog(this,
                titulo + ":\n" + ex.getMessage(),
                "Error de base de datos", JOptionPane.ERROR_MESSAGE);
    }
    private BigDecimal leerMonto(String texto) {
        try {
            BigDecimal monto = new BigDecimal(normalizarMonto(texto));
            if (monto.compareTo(BigDecimal.ZERO) <= 0 || monto.scale() > 2
                    || monto.compareTo(MONTO_MAXIMO) > 0) {
                return null;
            }
            return monto;
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    private LocalDate leerFecha(String texto) {
        try {
            return LocalDate.parse(texto, FORMATO);
        } catch (DateTimeParseException ex) {
            return null;
        }
    }

    private int leerAño(String texto) {
        try {
            int año = Integer.parseInt(texto.trim());
            return (año >= 2000 && año <= 2100) ? año : -1;
        } catch (NumberFormatException ex) {
            return -1;
        }
    }

    private String normalizarMonto(String texto) {
        String cantidad = texto.replace("$", "").replace(" ", "");
        if (cantidad.contains(",") && cantidad.contains(".")) {
            if (cantidad.lastIndexOf(',') > cantidad.lastIndexOf('.')) {
                cantidad = cantidad.replace(".", "").replace(',', '.');
            } else {
                cantidad = cantidad.replace(",", "");
            }
        } else if (cantidad.contains(",")) {
            cantidad = cantidad.replace(',', '.');
        }
        return cantidad;
    }

    private void registrarPago() {
        if (!Sesion.haySesion()) {
            JOptionPane.showMessageDialog(this,
                    "Inicia sesión desde el Login para poder registrar pagos.",
                    "Sin sesión", JOptionPane.WARNING_MESSAGE);
            return;
        }

        AlumnoItem alumno = (AlumnoItem) cmbAlumno.getSelectedItem();
        String metodoPago = (String) cmbMetodoPago.getSelectedItem();
        String montoTexto = txtMonto.getText().trim();
        String fechaTexto = txtFecha.getText().trim();

        if (alumno == null) {
            JOptionPane.showMessageDialog(this,
                    "No hay alumnos registrados. Primero registra al alumno.",
                    "Sin alumnos", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (montoTexto.isEmpty() || fechaTexto.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, complete todos los campos obligatorios.",
                    "Campos incompletos", JOptionPane.WARNING_MESSAGE);
            return;
        }

        BigDecimal monto = leerMonto(montoTexto);
        if (monto == null) {
            JOptionPane.showMessageDialog(this, "Ingrese un monto válido y mayor que cero.\nEjemplo: 250.00",
                    "Monto incorrecto", JOptionPane.WARNING_MESSAGE);
            txtMonto.requestFocus();
            return;
        }

        LocalDate fecha = leerFecha(fechaTexto);
        if (fecha == null) {
            JOptionPane.showMessageDialog(this, "La fecha debe ser válida y usar dd/MM/aaaa.",
                    "Fecha incorrecta", JOptionPane.WARNING_MESSAGE);
            txtFecha.requestFocus();
            return;
        }

        int mes = cmbMes.getSelectedIndex() + 1;
        int año = leerAño(txtAño.getText());
        if (año == -1) {
            JOptionPane.showMessageDialog(this, "Escribe un año válido (por ejemplo 2026).",
                    "Año incorrecto", JOptionPane.WARNING_MESSAGE);
            txtAño.requestFocus();
            return;
        }

        String numeroComprobante = "CP-" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS"));
        String sql = "INSERT INTO Comprobante_pago "
                + "(numero_comprobante, mes, `año`, fecha_pago, metodo_pago, monto_total, id_tutor, id_alumno, id_secretaria) "
                + "SELECT ?, ?, ?, ?, ?, ?, id_tutor, id_alumno, ? FROM Alumno WHERE id_alumno = ?";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, numeroComprobante);
            ps.setInt(2, mes);
            ps.setInt(3, año);
            ps.setDate(4, Date.valueOf(fecha));
            ps.setString(5, metodoPago);
            ps.setBigDecimal(6, monto);
            ps.setInt(7, Sesion.idSecretaria);
            ps.setInt(8, alumno.id);
            ps.executeUpdate();

        } catch (SQLException ex) {
            if (ex.getErrorCode() == 1062) {
                JOptionPane.showMessageDialog(this,
                        alumno.nombre + " ya tiene registrado el pago de " + MESES[mes - 1] + " " + año + ".",  "Pago duplicado", JOptionPane.WARNING_MESSAGE);
            } else {
                errorBD("No se pudo guardar el pago", ex);
            }
            return;
        }

        JOptionPane.showMessageDialog(this,
                "¡Pago registrado y guardado correctamente!\n\n"
                + "Comprobante: " + numeroComprobante + "\n"
                + "Alumno: " + alumno.nombre + "\n"
                + "Mes: " + MESES[mes - 1] + " " + año + "\n"
                + "Método de Pago: " + metodoPago + "\n"
                + "Monto: $" + monto.toPlainString() + "\n"
                + "Fecha: " + fecha.format(FORMATO),
                "Registro exitoso", JOptionPane.INFORMATION_MESSAGE);

        limpiarCampos();
    }

    private void guardarPagosDelMes() {
        JComboBox<String> cmbMesArchivo = new JComboBox<>(MESES);
        cmbMesArchivo.setSelectedIndex(LocalDate.now().getMonthValue() - 1);
        JTextField txtAñoArchivo = new JTextField(String.valueOf(LocalDate.now().getYear()));

        JPanel selector = new JPanel(new GridLayout(2, 2, 8, 8));
        selector.add(new JLabel("Mes:"));
        selector.add(cmbMesArchivo);
        selector.add(new JLabel("Año:"));
        selector.add(txtAñoArchivo);

        int respuesta = JOptionPane.showConfirmDialog(this, selector,
                "¿De qué mes quieres guardar los pagos?",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (respuesta != JOptionPane.OK_OPTION) {
            return;
        }

        int mes = cmbMesArchivo.getSelectedIndex() + 1;
        int año = leerAño(txtAñoArchivo.getText());
        if (año == -1) {
            JOptionPane.showMessageDialog(this, "Escribe un año válido (por ejemplo 2026).",
                    "Año incorrecto", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String nombreMes = MESES[mes - 1];

        List<Object[]> todos;
        try {
            todos = cargarPagos(null);
        } catch (SQLException ex) {
            errorBD("No se pudieron leer los pagos", ex);
            return;
        }

        String mesAño = String.format("%02d/%d", mes, año);
        List<Object[]> delMes = new ArrayList<>();
        BigDecimal totalMes = BigDecimal.ZERO;
        for (Object[] pago : todos) {
            String fecha = (String) pago[C_FECHA];
            if (fecha.substring(3).equals(mesAño)) {
                delMes.add(pago);
                totalMes = totalMes.add(new BigDecimal((String) pago[C_MONTO]));
            }
        }
        java.util.Collections.reverse(delMes);

        if (delMes.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                    "No hay pagos registrados en " + nombreMes + " " + año + ".",
                    "Sin pagos", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        JFileChooser elegir = new JFileChooser();
        elegir.setDialogTitle("Guardar pagos de " + nombreMes + " " + año);
        elegir.setFileFilter(new FileNameExtensionFilter("Archivo para Excel (*.csv)", "csv"));
        elegir.setSelectedFile(new File("pagos_" + nombreMes.toLowerCase() + "_" + año + ".csv"));
        if (elegir.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) {
            return;
        }

        File archivo = elegir.getSelectedFile();
        if (!archivo.getName().toLowerCase().endsWith(".csv")) {
            archivo = new File(archivo.getParentFile(), archivo.getName() + ".csv");
        }
        if (archivo.exists()) {
            int sobrescribir = JOptionPane.showConfirmDialog(this,
                    "El archivo ya existe. ¿Deseas reemplazarlo?",
                    "Archivo existente", JOptionPane.YES_NO_OPTION);
            if (sobrescribir != JOptionPane.YES_OPTION) {
                return;
            }
        }

        try (PrintWriter pw = new PrintWriter(
                new OutputStreamWriter(new FileOutputStream(archivo), StandardCharsets.UTF_8))) {

            pw.write('﻿');
            pw.println("Pagos de " + nombreMes + " " + año);
            pw.println("Comprobante,Alumno,Periodo pagado,Método de pago,Monto,Fecha de pago");
            for (Object[] pago : delMes) {
                pw.println(csv((String) pago[C_COMPROBANTE]) + ","
                        + csv((String) pago[C_ALUMNO]) + ","
                        + csv((String) pago[C_PERIODO]) + ","
                        + csv((String) pago[C_METODO]) + ","
                        + csv((String) pago[C_MONTO]) + ","
                        + csv((String) pago[C_FECHA]));
            }
            pw.println(",,,TOTAL DEL MES," + totalMes.toPlainString());

            if (pw.checkError()) {
                throw new IOException("Error al escribir el archivo");
            }

        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this,
                    "No se pudo guardar el archivo:\n" + ex.getMessage(),
                    "Error al guardar", JOptionPane.ERROR_MESSAGE);
            return;
        }

        JOptionPane.showMessageDialog(this,
                "Pagos de " + nombreMes + " " + año + " guardados en:\n" + archivo.getAbsolutePath(),
                "Archivo guardado", JOptionPane.INFORMATION_MESSAGE);
    }

    private String csv(String valor) {
        if (valor == null) {
            return "";
        }
        if (valor.contains(",") || valor.contains("\"") || valor.contains("\n")) {
            return "\"" + valor.replace("\"", "\"\"") + "\"";
        }
        return valor;
    }

    public void mostrarPagos() {
        mostrarPagos(null);
    }

    private void mostrarPagos(Integer idAlumno) {
        List<Object[]> pagos;
        try {
            pagos = cargarPagos(idAlumno);
        } catch (SQLException ex) {
            errorBD("No se pudieron leer los pagos", ex);
            return;
        }

        String[] columnas = {"ID", "ID alumno", "Mes", "Año",
                "Comprobante", "Alumno", "Periodo", "Método Pago", "Monto", "Fecha"};
        DefaultTableModel modelo = new DefaultTableModel(columnas, 0) {
            private static final long serialVersionUID = 1L;

            @Override
            public boolean isCellEditable(int fila, int columna) {
                return false;
            }
        };

        for (Object[] pago : pagos) {
            modelo.addRow(pago);
        }

        JTable tabla = new JTable(modelo);
        tabla.setRowHeight(32);
        tabla.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        tabla.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 13));
        tabla.getTableHeader().setBackground(new Color(235, 244, 251));
        tabla.setSelectionBackground(new Color(210, 232, 248));
        tabla.setGridColor(new Color(218, 228, 239));
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        for (int i = 0; i < 4; i++) {
            tabla.removeColumn(tabla.getColumnModel().getColumn(0));
        }

        TableRowSorter<DefaultTableModel> ordenador = new TableRowSorter<>(modelo);
        tabla.setRowSorter(ordenador);

        JTextField filtro = new JTextField();
        filtro.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        filtro.setBorder(new LineBorder(new Color(196, 210, 225), 1, true));
        filtro.getDocument().addDocumentListener(new DocumentListener() {
            private void filtrar() {
                String texto = filtro.getText().trim();

                if (texto.isEmpty()) {
                    ordenador.setRowFilter(null);
                } else {
                    ordenador.setRowFilter(
                            RowFilter.regexFilter(
                                    "(?i)" + java.util.regex.Pattern.quote(texto)));
                }
            }

            @Override public void insertUpdate(DocumentEvent e) { filtrar(); }
            @Override public void removeUpdate(DocumentEvent e) { filtrar(); }
            @Override public void changedUpdate(DocumentEvent e) { filtrar(); }
        });

        JPanel superior = new JPanel(new BorderLayout(8, 0));
        superior.setBackground(Color.WHITE);
        superior.setBorder(BorderFactory.createEmptyBorder(14, 16, 6, 16));
        JLabel lblBuscar = new JLabel("Buscar:");
        lblBuscar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        lblBuscar.setForeground(new Color(47, 65, 85));
        superior.add(lblBuscar, BorderLayout.WEST);
        superior.add(filtro, BorderLayout.CENTER);

        JButton btnModificar = new JButton("Modificar");
        btnModificar.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnModificar.setForeground(Color.WHITE);
        btnModificar.setBackground(new Color(31, 104, 160));
        btnModificar.setFocusPainted(false);
        btnModificar.setPreferredSize(new Dimension(116, 39));
        btnModificar.setBorder(new LineBorder(new Color(31, 104, 160), 1, true));
        btnModificar.addActionListener(e -> {
            int filaVista = tabla.getSelectedRow();
            if (filaVista == -1) {
                JOptionPane.showMessageDialog(tabla, "Selecciona un pago para modificar.");
                return;
            }
            editarPago(modelo, tabla.convertRowIndexToModel(filaVista));
        });

        JButton btnEliminar = new JButton("Eliminar");
        btnEliminar.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnEliminar.setForeground(new Color(31, 104, 160));
        btnEliminar.setBackground(new Color(235, 244, 251));
        btnEliminar.setFocusPainted(false);
        btnEliminar.setPreferredSize(new Dimension(116, 39));
        btnEliminar.setBorder(new LineBorder(new Color(196, 210, 225), 1, true));
        btnEliminar.addActionListener(e -> {
            int filaVista = tabla.getSelectedRow();
            if (filaVista == -1) {
                JOptionPane.showMessageDialog(tabla, "Selecciona un pago para eliminar.");
                return;
            }
            eliminarPago(modelo, tabla.convertRowIndexToModel(filaVista));
        });

        JButton btnGuardarMes = new JButton("Guardar pagos del mes");
        btnGuardarMes.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnGuardarMes.setForeground(new Color(31, 104, 160));
        btnGuardarMes.setBackground(new Color(235, 244, 251));
        btnGuardarMes.setFocusPainted(false);
        btnGuardarMes.setPreferredSize(new Dimension(200, 39));
        btnGuardarMes.setBorder(new LineBorder(new Color(196, 210, 225), 1, true));
        btnGuardarMes.addActionListener(e -> guardarPagosDelMes());

        JButton btnCerrar = new JButton("Cerrar");
        btnCerrar.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnCerrar.setForeground(new Color(31, 104, 160));
        btnCerrar.setBackground(new Color(235, 244, 251));
        btnCerrar.setFocusPainted(false);
        btnCerrar.setPreferredSize(new Dimension(116, 39));
        btnCerrar.setBorder(new LineBorder(new Color(196, 210, 225), 1, true));

        JDialog dialogo = new JDialog(this, "Pagos registrados", true);
        btnCerrar.addActionListener(e -> dialogo.dispose());

        JPanel inferior = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 12));
        inferior.setBackground(Color.WHITE);
        inferior.setBorder(BorderFactory.createEmptyBorder(2, 10, 8, 10));
        inferior.add(btnModificar);
        inferior.add(btnEliminar);
        inferior.add(btnGuardarMes);
        inferior.add(btnCerrar);

        dialogo.getContentPane().setBackground(Color.WHITE);
        dialogo.getContentPane().setLayout(new BorderLayout(10, 10));
        dialogo.getContentPane().add(superior, BorderLayout.NORTH);
        dialogo.getContentPane().add(new JScrollPane(tabla), BorderLayout.CENTER);
        dialogo.getContentPane().add(inferior, BorderLayout.SOUTH);
        dialogo.setSize(920, 480);
        dialogo.setLocationRelativeTo(this);
        dialogo.setVisible(true);
    }

    private static final int C_ID = 0, C_ID_ALUMNO = 1, C_MES = 2, C_AÑO = 3,
            C_COMPROBANTE = 4, C_ALUMNO = 5, C_PERIODO = 6, C_METODO = 7, C_MONTO = 8, C_FECHA = 9;

    private void editarPago(DefaultTableModel modelo, int fila) {
        int idComprobante = (Integer) modelo.getValueAt(fila, C_ID);
        int idAlumnoActual = (Integer) modelo.getValueAt(fila, C_ID_ALUMNO);

        List<AlumnoItem> alumnos;
        try {
            alumnos = cargarAlumnos();
        } catch (SQLException ex) {
            errorBD("No se pudieron cargar los alumnos", ex);
            return;
        }

        JComboBox<AlumnoItem> alumno = new JComboBox<>();
        for (AlumnoItem a : alumnos) {
            alumno.addItem(a);
            if (a.id == idAlumnoActual) {
                alumno.setSelectedItem(a);
            }
        }
        JComboBox<String> metodo = new JComboBox<>(METODOS);
        metodo.setSelectedItem(modelo.getValueAt(fila, C_METODO).toString());
        JTextField monto = new JTextField(modelo.getValueAt(fila, C_MONTO).toString());
        JTextField fecha = new JTextField(modelo.getValueAt(fila, C_FECHA).toString());
        JComboBox<String> mes = new JComboBox<>(MESES);
        mes.setSelectedIndex((Integer) modelo.getValueAt(fila, C_MES) - 1);
        JTextField año = new JTextField(modelo.getValueAt(fila, C_AÑO).toString());

        JPanel formulario = new JPanel(new GridLayout(6, 2, 8, 8));
        formulario.add(new JLabel("Alumno:"));
        formulario.add(alumno);
        formulario.add(new JLabel("Método pago:"));
        formulario.add(metodo);
        formulario.add(new JLabel("Monto:"));
        formulario.add(monto);
        formulario.add(new JLabel("Fecha (dd/MM/aaaa):"));
        formulario.add(fecha);
        formulario.add(new JLabel("Mes:"));
        formulario.add(mes);
        formulario.add(new JLabel("Año:"));
        formulario.add(año);

        int resultado = JOptionPane.showConfirmDialog(
                this, formulario, "Modificar pago",
                JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE);

        if (resultado != JOptionPane.OK_OPTION) {
            return;
        }

        AlumnoItem nuevoAlumno = (AlumnoItem) alumno.getSelectedItem();
        String nuevoMetodo = (String) metodo.getSelectedItem();
        BigDecimal nuevoMonto = leerMonto(monto.getText().trim());
        LocalDate nuevaFecha = leerFecha(fecha.getText().trim());
        int nuevoMes = mes.getSelectedIndex() + 1;
        int nuevoAño = leerAño(año.getText());

        if (nuevoAlumno == null) {
            JOptionPane.showMessageDialog(this, "Selecciona un alumno.");
            return;
        }
        if (nuevoMonto == null) {
            JOptionPane.showMessageDialog(this, "El monto debe ser válido, mayor que cero y tener máximo dos decimales.");
            return;
        }
        if (nuevaFecha == null) {
            JOptionPane.showMessageDialog(this, "La fecha debe ser válida y usar dd/MM/aaaa.");
            return;
        }
        if (nuevoAño == -1) {
            JOptionPane.showMessageDialog(this, "Escribe un año válido (por ejemplo 2026).");
            return;
        }

        String sql = "UPDATE Comprobante_pago SET id_alumno = ?, "
                + "id_tutor = (SELECT id_tutor FROM Alumno WHERE id_alumno = ?), "
                + "metodo_pago = ?, monto_total = ?, fecha_pago = ?, mes = ?, `año` = ? "
                + "WHERE id_comprobante = ?";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, nuevoAlumno.id);
            ps.setInt(2, nuevoAlumno.id);
            ps.setString(3, nuevoMetodo);
            ps.setBigDecimal(4, nuevoMonto);
            ps.setDate(5, Date.valueOf(nuevaFecha));
            ps.setInt(6, nuevoMes);
            ps.setInt(7, nuevoAño);
            ps.setInt(8, idComprobante);
            ps.executeUpdate();

        } catch (SQLException ex) {
            if (ex.getErrorCode() == 1062) {
                JOptionPane.showMessageDialog(this,
                        nuevoAlumno.nombre + " ya tiene registrado el pago de " + MESES[nuevoMes - 1] + " " + nuevoAño + ".",
                        "Pago duplicado", JOptionPane.WARNING_MESSAGE);
            } else {
                errorBD("No se pudo guardar el cambio", ex);
            }
            return;
        }

        modelo.setValueAt(nuevoAlumno.id, fila, C_ID_ALUMNO);
        modelo.setValueAt(nuevoMes, fila, C_MES);
        modelo.setValueAt(nuevoAño, fila, C_AÑO);
        modelo.setValueAt(nuevoAlumno.nombre, fila, C_ALUMNO);
        modelo.setValueAt(MESES[nuevoMes - 1] + " " + nuevoAño, fila, C_PERIODO);
        modelo.setValueAt(nuevoMetodo, fila, C_METODO);
        modelo.setValueAt(nuevoMonto.toPlainString(), fila, C_MONTO);
        modelo.setValueAt(nuevaFecha.format(FORMATO), fila, C_FECHA);

        JOptionPane.showMessageDialog(this, "El pago se modificó correctamente.");
    }

    private void eliminarPago(DefaultTableModel modelo, int fila) {
        int idComprobante = (Integer) modelo.getValueAt(fila, C_ID);
        String nombre = modelo.getValueAt(fila, C_ALUMNO).toString();
        String periodo = modelo.getValueAt(fila, C_PERIODO).toString();

        int respuesta = JOptionPane.showConfirmDialog(
                this,
                "¿Deseas eliminar este pago?\n\nAlumno: " + nombre + "\nPeriodo: " + periodo,
                "Confirmar eliminación",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE);

        if (respuesta != JOptionPane.YES_OPTION) {
            return;
        }

        String sql = "DELETE FROM Comprobante_pago WHERE id_comprobante = ?";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idComprobante);
            ps.executeUpdate();

        } catch (SQLException ex) {
            errorBD("No se pudo eliminar el registro", ex);
            return;
        }

        modelo.removeRow(fila);
        JOptionPane.showMessageDialog(this, "El pago se eliminó correctamente.");
    }

    private void limpiarCampos() {
        if (cmbAlumno.getItemCount() > 0) {
            cmbAlumno.setSelectedIndex(0);
        }
        cmbMetodoPago.setSelectedIndex(0);
        txtMonto.setText("");
        txtFecha.setText(LocalDate.now().format(FORMATO));
        cmbMes.setSelectedIndex(LocalDate.now().getMonthValue() - 1);
        txtAño.setText(String.valueOf(LocalDate.now().getYear()));
        cmbAlumno.requestFocus();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ex) {
            }

            new VentanaPagos().setVisible(true);
        });
    }
}
