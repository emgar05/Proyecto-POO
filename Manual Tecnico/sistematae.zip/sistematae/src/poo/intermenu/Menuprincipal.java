package poo.intermenu;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.UIManager;

public class Menuprincipal extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JButton btnAlumno;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Menuprincipal frame = new Menuprincipal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Menuprincipal() {
		setTitle("Menú principal");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 920, 600);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(243, 247, 251));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBorder(new LineBorder(new Color(218, 228, 239), 1, true));
		panel.setBounds(18, 16, 868, 82);
		contentPane.add(panel);
		panel.setLayout(null);

		JLabel lblTitulo = new JLabel("Menú principal");
		lblTitulo.setForeground(new Color(28, 59, 91));
		lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 19));
		lblTitulo.setBounds(353, 21, 145, 34);
		panel.add(lblTitulo);

		JLabel lblSecretaria = new JLabel("Secretaria");
		lblSecretaria.setForeground(new Color(47, 65, 85));
		lblSecretaria.setFont(new Font("Segoe UI", Font.BOLD, 14));
		lblSecretaria.setHorizontalAlignment(SwingConstants.RIGHT);
		lblSecretaria.setBounds(649, 25, 128, 30);
		if (Sesion.nombreSecretaria != null) {
			lblSecretaria.setToolTipText(Sesion.nombreSecretaria);
		}
		panel.add(lblSecretaria);

		JLabel lblCerrar = new JLabel("Cerrar sesión");
		lblCerrar.setForeground(new Color(100, 116, 139));
		lblCerrar.setFont(new Font("Segoe UI", Font.PLAIN, 13));
		lblCerrar.setBounds(61, 21, 118, 32);
		panel.add(lblCerrar);

		JButton btnCerrarSesion = new JButton("");
		btnCerrarSesion.setIcon(Imagenes.cargar("cerrar sesion.jpg", 24, 24));
		btnCerrarSesion.setBackground(new Color(243, 247, 251));
		btnCerrarSesion.setBorder(new LineBorder(new Color(218, 228, 239), 1, true));
		btnCerrarSesion.setFocusPainted(false);
		btnCerrarSesion.setToolTipText("Cerrar sesión");
		btnCerrarSesion.setBounds(10, 15, 44, 44);
		btnCerrarSesion.addActionListener(e -> {
			Sesion.cerrar();
			new Login().setVisible(true);
			dispose();
		});
		panel.add(btnCerrarSesion);

		JLabel lblUsuario = new JLabel("");
		lblUsuario.setIcon(Imagenes.cargar("usuario.png", 46, 46));
		lblUsuario.setBounds(790, 17, 52, 52);
		panel.add(lblUsuario);

		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.WHITE);
		panel_1.setBorder(new LineBorder(new Color(218, 228, 239), 1, true));
		panel_1.setBounds(18, 112, 868, 426);
		contentPane.add(panel_1);
		panel_1.setLayout(null);

		JLabel lblOpciones = new JLabel("Seleccione una opción");
		lblOpciones.setForeground(new Color(28, 59, 91));
		lblOpciones.setFont(new Font("Segoe UI", Font.BOLD, 21));
		lblOpciones.setBounds(42, 29, 480, 32);
		panel_1.add(lblOpciones);

		btnAlumno = new JButton("Registrar alumno");
		btnAlumno.setForeground(Color.WHITE);
		btnAlumno.setBackground(new Color(31, 104, 160));
		btnAlumno.setBorder(new LineBorder(new Color(31, 104, 160), 1, true));
		btnAlumno.setFocusPainted(false);
		btnAlumno.setFont(new Font("Segoe UI", Font.BOLD, 16));
		btnAlumno.setBounds(42, 115, 375, 73);
		btnAlumno.addActionListener(e -> new RegistroAlumno().setVisible(true));
		panel_1.add(btnAlumno);

		JButton btnPago = new JButton("Registrar pago");
		btnPago.setForeground(Color.WHITE);
		btnPago.setBackground(new Color(31, 104, 160));
		btnPago.setBorder(new LineBorder(new Color(31, 104, 160), 1, true));
		btnPago.setFocusPainted(false);
		btnPago.setFont(new Font("Segoe UI", Font.BOLD, 16));
		btnPago.setBounds(452, 115, 375, 73);
		btnPago.addActionListener(e -> new VentanaPagos().setVisible(true));
		panel_1.add(btnPago);

		JButton btnConsultar = new JButton("Consultar pagos");
		btnConsultar.setForeground(new Color(31, 104, 160));
		btnConsultar.setBackground(new Color(235, 244, 251));
		btnConsultar.setBorder(new LineBorder(new Color(196, 210, 225), 1, true));
		btnConsultar.setFocusPainted(false);
		btnConsultar.setFont(new Font("Segoe UI", Font.BOLD, 16));
		btnConsultar.setBounds(42, 208, 375, 73);
		btnConsultar.addActionListener(e -> {
			VentanaPagos v = new VentanaPagos();
			v.setVisible(true);
			v.mostrarPagos();
		});
		panel_1.add(btnConsultar);

		JButton btnVenta = new JButton("Registrar venta");
		btnVenta.setForeground(new Color(31, 104, 160));
		btnVenta.setBackground(new Color(235, 244, 251));
		btnVenta.setBorder(new LineBorder(new Color(196, 210, 225), 1, true));
		btnVenta.setFocusPainted(false);
		btnVenta.setFont(new Font("Segoe UI", Font.BOLD, 16));
		btnVenta.setBounds(452, 208, 375, 73);
		btnVenta.addActionListener(e -> new RegistroVentas().setVisible(true));
		panel_1.add(btnVenta);

		JLabel lblMarca = new JLabel("TAE KWON DO MARCIAL DE MÉXICO A. C.");
		lblMarca.setForeground(new Color(100, 116, 139));
		lblMarca.setFont(new Font("Segoe UI", Font.BOLD, 13));
		lblMarca.setBounds(42, 347, 525, 28);
		panel_1.add(lblMarca);

		JLabel lblLogo = new JLabel("");
		lblLogo.setIcon(Imagenes.cargar("logo.jpeg", 94, 94));
		lblLogo.setHorizontalAlignment(SwingConstants.CENTER);
		lblLogo.setBounds(726, 307, 100, 100);
		panel_1.add(lblLogo);

		Escalador.activar(this, contentPane);
	}
}
