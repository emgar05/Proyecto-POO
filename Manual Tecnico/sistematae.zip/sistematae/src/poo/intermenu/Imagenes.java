package poo.intermenu;

import java.awt.Image;
import java.net.URL;
import javax.swing.ImageIcon;

public class Imagenes {
	
    public static class Escalable extends ImageIcon {
        private static final long serialVersionUID = 1L;
        private final transient Image original;

        Escalable(Image original, int ancho, int alto) {
            super(original.getScaledInstance(ancho, alto, Image.SCALE_SMOOTH));
            this.original = original;
        }

    public Escalable conTamano(int ancho, int alto) {
            return new Escalable(original, ancho, alto);
        }
    }

    public static ImageIcon cargar(String nombreArchivo, int ancho, int alto) {
        URL url = Imagenes.class.getResource("/imagenes/" + nombreArchivo);
        if (url == null) {
            System.out.println("No se encontró la imagen: /imagenes/" + nombreArchivo);
            return null;
        }
        return new Escalable(new ImageIcon(url).getImage(), ancho, alto);
    }
}
