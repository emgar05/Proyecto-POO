package poo.intermenu;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class RegistroAlumno extends JFrame {

    private static final long serialVersionUID = 1L;

    private final JTextField[] campos = new JTextField[7];

    private static final Font FUENTE = new Font("Segoe UI", Font.BOLD, 14);

    public RegistroAlumno() {
        setTitle("Registro alumno");
        setSize(920, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setResizable(true);
        setMinimumSize(new Dimension(800, 560));

        JPanel raiz = new JPanel(new BorderLayout(0, 14));
        raiz.setBackground(new Color(243, 247, 251));
        raiz.setBorder(new EmptyBorder(16, 18, 16, 18));
        setContentPane(raiz);

        raiz.add(crearEncabezado(), BorderLayout.NORTH);
        raiz.add(crearFormulario(), BorderLayout.CENTER);
        raiz.add(crearBotones(), BorderLayout.SOUTH);
    }

    private JPanel crearEncabezado() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBackground(Color.WHITE);
        p.setBorder(new LineBorder(new Color(218, 228, 239), 1, true));
        p.setPreferredSize(new Dimension(0, 82));

        JLabel logo = new JLabel();
        logo.setPreferredSize(new Dimension(80, 76));
        ImageIcon icono = Imagenes.cargar("logo.jpeg", 60, 60);
        if (icono != null) {
            logo.setIcon(icono);
        } else {
            logo.setText("LOGO");
        }

        JLabel titulo = new JLabel("Registro alumno");
        titulo.setForeground(new Color(28, 59, 91));
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 19));

        JPanel izquierda = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 2));
        izquierda.setOpaque(false);
        izquierda.add(logo);
        izquierda.add(titulo);

        JLabel rol = new JLabel("Secretaria");
        rol.setForeground(new Color(47, 65, 85));
        rol.setFont(new Font("Segoe UI", Font.BOLD, 14));

        JPanel derecha = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 14));
        derecha.setOpaque(false);
        derecha.add(rol);
        derecha.add(new Avatar());

        p.add(izquierda, BorderLayout.WEST);
        p.add(derecha, BorderLayout.EAST);
        return p;
    }

    private JPanel crearFormulario() {
        JPanel p = new JPanel(new GridBagLayout());
        p.setBackground(Color.WHITE);
        p.setBorder(new CompoundBorder(
                new LineBorder(new Color(218, 228, 239), 1, true),
                new EmptyBorder(8, 46, 8, 46)));

        String[] etiquetas = {
            "Nombre del alumno:", "Edad:", "CURP:", "Certificado médico:",
            "Nombre del tutor:", "Teléfono del tutor:", "Correo del tutor:"};
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 8, 6, 8);
        gbc.weighty = 1; 

        for (int i = 0; i < etiquetas.length; i++) {
            JLabel lbl = new JLabel(etiquetas[i]);
            lbl.setFont(FUENTE);
            lbl.setForeground(new Color(47, 65, 85));
            gbc.gridx = 0;
            gbc.gridy = i;
            gbc.weightx = 0;
            gbc.fill = GridBagConstraints.NONE;
            gbc.anchor = GridBagConstraints.WEST;
            gbc.ipadx = 36;
            p.add(lbl, gbc);

            JTextField txt = new JTextField();
            txt.setBorder(new CompoundBorder(
                    new LineBorder(new Color(196, 210, 225), 1, true),
                    new EmptyBorder(0, 12, 0, 12)));
            txt.setPreferredSize(new Dimension(0, 38));
            txt.setFont(new Font("Segoe UI", Font.PLAIN, 14));
            campos[i] = txt;

            gbc.gridx = 1;
            gbc.weightx = 1;
            gbc.fill = GridBagConstraints.HORIZONTAL;
            gbc.ipadx = 0;
            p.add(txt, gbc);
        }
        return p;
    }

    private JPanel crearBotones() {
        JPanel p = new JPanel(new FlowLayout(FlowLayout.RIGHT, 12, 12));
        p.setBackground(Color.WHITE);
        p.setBorder(new LineBorder(new Color(218, 228, 239), 1, true));
        p.setPreferredSize(new Dimension(0, 68));
        JButton btnRegistrar = crearBoton("Registrar");
        JButton btnCancelar = crearBoton("Cancelar");
        btnRegistrar.setForeground(Color.WHITE);
        btnRegistrar.setBackground(new Color(31, 104, 160));
        btnRegistrar.setBorder(new LineBorder(new Color(31, 104, 160), 1, true));
        btnRegistrar.addActionListener(e -> registrar());
        btnCancelar.addActionListener(e -> limpiar());
        p.add(btnRegistrar);
        p.add(btnCancelar);
        return p;
    }

    private JButton crearBoton(String texto) {
        JButton b = new JButton(texto);
        b.setFont(new Font("Segoe UI", Font.BOLD, 14));
        b.setForeground(new Color(31, 104, 160));
        b.setBackground(new Color(235, 244, 251));
        b.setFocusPainted(false);
        b.setPreferredSize(new Dimension(144, 42));
        b.setBorder(new LineBorder(new Color(196, 210, 225), 1, true));
        return b;
    }

    private void registrar() {
        String nombre = campos[0].getText().trim();
        String edadTxt = campos[1].getText().trim();
        String curp = campos[2].getText().trim().toUpperCase();
        String certificado = campos[3].getText().trim();
        String nombreTutor = campos[4].getText().trim();
        String telTutor = campos[5].getText().trim();
        String correoTutor = campos[6].getText().trim();

        if (!Sesion.haySesion()) {
            JOptionPane.showMessageDialog(this,
                    "Inicia sesión desde el Login para poder registrar alumnos.",
                    "Sin sesión", JOptionPane.WARNING_MESSAGE);
            return;
        }

        if (nombre.isEmpty() || edadTxt.isEmpty() || nombreTutor.isEmpty() || telTutor.isEmpty()) {
            error("Llena nombre, edad y los datos del tutor (nombre y teléfono).", campos[0]);
            return;
        }
        int edad;
        try {
            edad = Integer.parseInt(edadTxt);
        } catch (NumberFormatException ex) {
            error("La edad debe ser un número.", campos[1]);
            return;
        }
        if (edad < 1 || edad > 100) {
            error("Escribe una edad válida.", campos[1]);
            return;
        }
        if (!curp.isEmpty() && !curp.matches("[A-Z0-9]{18}")) {
            error("La CURP debe tener 18 letras/números.", campos[2]);
            return;
        }
        if (!telTutor.matches("\\d{10}")) {
            error("El teléfono del tutor debe tener 10 dígitos.", campos[5]);
            return;
        }
        if (!correoTutor.isEmpty() && !correoTutor.matches("^[\\w.+-]+@[\\w-]+(\\.[\\w-]+)+$")) {
            error("El correo del tutor no es válido.", campos[6]);
            return;
        }

        Connection con = null;
        try {
            con = Conexion.getConexion();
            con.setAutoCommit(false);

            int idTutor = buscarOCrearTutor(con, nombreTutor, telTutor, correoTutor);

            String sql = "INSERT INTO Alumno (nombre, edad, certificado_medico, curp, id_tutor, id_secretaria) "
                    + "VALUES (?, ?, ?, ?, ?, ?)";
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setString(1, nombre);
                ps.setInt(2, edad);
                ps.setString(3, certificado.isEmpty() ? null : certificado);
                ps.setString(4, curp.isEmpty() ? null : curp);
                ps.setInt(5, idTutor);
                ps.setInt(6, Sesion.idSecretaria);
                ps.executeUpdate();
            }

            con.commit();

        } catch (SQLException ex) {
            if (con != null) {
                try { con.rollback(); } catch (SQLException ignorar) { }
            }
            if (ex.getErrorCode() == 1062) {
                error("Ya existe un alumno con esa CURP.", campos[2]);
            } else {
                JOptionPane.showMessageDialog(this,
                        "No se pudo guardar el alumno en la base de datos:\n" + ex.getMessage(),
                        "Error de base de datos", JOptionPane.ERROR_MESSAGE);
            }
            return;
        } finally {
            if (con != null) {
                try { con.close(); } catch (SQLException ignorar) { }
            }
        }

        JOptionPane.showMessageDialog(this,
                "Alumno registrado:\n" + nombre + "\nTutor: " + nombreTutor,
                "Registro exitoso", JOptionPane.INFORMATION_MESSAGE);
        limpiar();
    }
    
    private int buscarOCrearTutor(Connection con, String nombre, String telefono, String correo)
            throws SQLException {

        String buscar = "SELECT id_tutor FROM Tutor WHERE nombre = ? AND telefono = ?";
        try (PreparedStatement ps = con.prepareStatement(buscar)) {
            ps.setString(1, nombre);
            ps.setString(2, telefono);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt("id_tutor");
                }
            }
        }

        String insertar = "INSERT INTO Tutor (nombre, telefono, correo) VALUES (?, ?, ?)";
        try (PreparedStatement ps = con.prepareStatement(insertar, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, nombre);
            ps.setString(2, telefono);
            ps.setString(3, correo.isEmpty() ? null : correo);
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                rs.next();
                return rs.getInt(1);
            }
        }
    }

    private void limpiar() {
        for (JTextField c : campos) {
            c.setText("");
        }
        campos[0].requestFocus();
    }

    private void error(String mensaje, JTextField campo) {
        JOptionPane.showMessageDialog(this, mensaje, "Dato incorrecto", JOptionPane.ERROR_MESSAGE);
        campo.requestFocus();
    }

    private static class Avatar extends JComponent {
        private static final long serialVersionUID = 1L;

        Avatar() { setPreferredSize(new Dimension(52, 52)); }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(new Color(235, 244, 251));
            g2.fillOval(0, 0, 50, 50);
            g2.setColor(new Color(31, 104, 160));
            g2.fillOval(18, 10, 14, 14);
            g2.fillArc(10, 29, 30, 26, 0, 180);
            g2.setStroke(new BasicStroke(1.5f));
            g2.drawOval(1, 1, 48, 48);
            g2.dispose();
        }
    }
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new RegistroAlumno().setVisible(true));
    }
}
