package poo.intermenu;

import java.awt.Component;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Rectangle;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.HashMap;
import java.util.Map;

import javax.swing.AbstractButton;
import javax.swing.Icon;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingUtilities;
import javax.swing.Timer;


public class Escalador {
    private static class Original {
        Rectangle bounds;
        Font fuente;
        Dimension icono; 
    }

    private final JFrame frame;
    private final JComponent raiz;
    private final Map<Component, Original> originales = new HashMap<>();
    private Dimension base;    
    private Timer temporizadorIconos;

    public static void activar(JFrame frame, JComponent raiz) {
        new Escalador(frame, raiz);
    }

    private Escalador(JFrame frame, JComponent raiz) {
        this.frame = frame;
        this.raiz = raiz;

        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowOpened(WindowEvent e) {
                SwingUtilities.invokeLater(() -> iniciar());
            }
        });
    }

    private void iniciar() {
        base = raiz.getSize();
        if (base.width <= 0 || base.height <= 0) {
            return;
        }

        registrar(raiz);
        frame.setMinimumSize(frame.getSize());

        temporizadorIconos = new Timer(150, e -> escalarIconos());
        temporizadorIconos.setRepeats(false);

        raiz.addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                escalar();
            }
        });
    }

    private void registrar(Container contenedor) {
        if (contenedor.getLayout() != null) {
            return; 
        }
        for (Component hijo : contenedor.getComponents()) {
            Original o = new Original();
            o.bounds = hijo.getBounds();
            o.fuente = hijo.getFont();

            Icon icono = iconoDe(hijo);
            if (icono instanceof Imagenes.Escalable) {
                o.icono = new Dimension(icono.getIconWidth(), icono.getIconHeight());
            }

            originales.put(hijo, o);

            if (hijo instanceof Container) {
                registrar((Container) hijo);
            }
        }
    }

    private Icon iconoDe(Component c) {
        if (c instanceof JLabel) {
            return ((JLabel) c).getIcon();
        }
        if (c instanceof AbstractButton) {
            return ((AbstractButton) c).getIcon();
        }
        return null;
    }

    private void escalar() {
        double sx = raiz.getWidth() / (double) base.width;
        double sy = raiz.getHeight() / (double) base.height;
        double sFuente = Math.min(sx, sy);

        for (Map.Entry<Component, Original> par : originales.entrySet()) {
            Component c = par.getKey();
            Original o = par.getValue();

            c.setBounds(
                    (int) Math.round(o.bounds.x * sx),
                    (int) Math.round(o.bounds.y * sy),
                    (int) Math.round(o.bounds.width * sx),
                    (int) Math.round(o.bounds.height * sy));

            if (o.fuente != null) {
                c.setFont(o.fuente.deriveFont((float) (o.fuente.getSize2D() * sFuente)));
            }
        }

        temporizadorIconos.restart();
        raiz.repaint();
    }

    private void escalarIconos() {
        double s = Math.min(raiz.getWidth() / (double) base.width,
                            raiz.getHeight() / (double) base.height);

        for (Map.Entry<Component, Original> par : originales.entrySet()) {
            Original o = par.getValue();
            if (o.icono == null) {
                continue;
            }
            Component c = par.getKey();
            Imagenes.Escalable actual = (Imagenes.Escalable) iconoDe(c);
            if (actual == null) {
                continue;
            }
            int w = Math.max(1, (int) Math.round(o.icono.width * s));
            int h = Math.max(1, (int) Math.round(o.icono.height * s));
            Imagenes.Escalable nuevo = actual.conTamano(w, h);

            if (c instanceof JLabel) {
                ((JLabel) c).setIcon(nuevo);
            } else if (c instanceof AbstractButton) {
                ((AbstractButton) c).setIcon(nuevo);
            }
        }
    }
}

