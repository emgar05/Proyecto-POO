package poo.intermenu;

public class Sesion {
    public static int idSecretaria = 0;
    public static String nombreSecretaria = null;

    public static void cerrar() {
        idSecretaria = 0;
        nombreSecretaria = null;
    }

    public static boolean haySesion() {
        return idSecretaria != 0;
    }
}
