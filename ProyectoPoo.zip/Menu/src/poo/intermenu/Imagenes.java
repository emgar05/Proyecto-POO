package poo.intermenu;

import java.awt.Image;
import java.net.URL;

import javax.swing.ImageIcon;


public class Imagenes {

    public static ImageIcon cargar(String nombreArchivo, int ancho, int alto) {
        URL url = Imagenes.class.getResource("/imagenes/" + nombreArchivo);
        if (url == null) {
            System.out.println("No se encontró la imagen: /imagenes/" + nombreArchivo);
            return null;
        }
        Image img = new ImageIcon(url).getImage().getScaledInstance(ancho, alto, Image.SCALE_SMOOTH);
        return new ImageIcon(img);
    }
}
