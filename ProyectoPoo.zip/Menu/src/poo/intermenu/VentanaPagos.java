package poo.intermenu;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import javax.swing.border.LineBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.util.ArrayList;
import java.util.List;

public class VentanaPagos extends JFrame {
    private static final long serialVersionUID = 1L;
    private static class AlumnoItem {
        final int id;
        final String nombre;

        AlumnoItem(int id, String nombre) {
            this.id = id;
            this.nombre = nombre;
        }

        @Override
        public String toString() {
            return nombre;
        }
    }

    private JComboBox<AlumnoItem> cmbAlumno;
    private JComboBox<String> cmbMetodoPago;
    private JTextField txtMonto;
    private JTextField txtFecha;
    private JComboBox<String> cmbMes;
    private JTextField txtAnio;

    private static final DateTimeFormatter FORMATO =
            DateTimeFormatter.ofPattern("dd/MM/uuuu").withResolverStyle(ResolverStyle.STRICT);

    private static final String[] METODOS = {"Efectivo", "Transferencia", "Tarjeta"};

    private static final String[] MESES = {"Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
            "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"};

    private static final BigDecimal MONTO_MAXIMO = new BigDecimal("999999.99");

    public VentanaPagos() {
        setTitle("Sistema de pagos");
        setSize(750, 480);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel panel = new JPanel(null);
        panel.setBackground(Color.WHITE);
        getContentPane().add(panel);

        JLabel lblLogoEscuela = new JLabel(Imagenes.cargar("logo.jpeg", 50, 50));
        lblLogoEscuela.setBounds(25, 12, 50, 50);
        panel.add(lblLogoEscuela);

        JLabel lblTitulo = new JLabel("Registro de pagos ");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 15));
        lblTitulo.setForeground(new Color(30, 30, 30));
        lblTitulo.setBounds(85, 25, 180, 25);
        panel.add(lblTitulo);

        JLabel lblSecretaria = new JLabel("Secretaria");
        lblSecretaria.setFont(new Font("Arial", Font.BOLD, 15));
        lblSecretaria.setForeground(new Color(30, 30, 30));
        lblSecretaria.setBounds(540, 25, 85, 25);
        panel.add(lblSecretaria);

        JPanel panelAvatarUsuario = new JPanel() {
            private static final long serialVersionUID = 1L;

            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                int w = getWidth();
                int h = getHeight();

                g2.setColor(Color.BLACK);
                g2.setStroke(new BasicStroke(1.8f));
                g2.drawOval(2, 2, w - 4, h - 4);

                g2.fillOval(w / 2 - 8, 11, 16, 16);
                g2.fillArc(w / 2 - 16, 28, 32, 24, 0, 180);
            }
        };
        panelAvatarUsuario.setBounds(635, 10, 52, 52);
        panelAvatarUsuario.setBackground(Color.WHITE);
        panel.add(panelAvatarUsuario);

        JSeparator separador = new JSeparator();
        separador.setForeground(Color.BLACK);
        separador.setBackground(Color.BLACK);
        separador.setBounds(20, 72, 695, 2);
        panel.add(separador);

        LineBorder bordoCampos = new LineBorder(new Color(100, 100, 100), 1);
        Font fuenteEtiqueta = new Font("Arial", Font.BOLD, 13);

        JLabel lblNombre = new JLabel("Alumno:");
        lblNombre.setFont(fuenteEtiqueta);
        lblNombre.setBounds(95, 125, 70, 25);
        panel.add(lblNombre);

        cmbAlumno = new JComboBox<>();
        cmbAlumno.setBounds(175, 122, 490, 32);
        cmbAlumno.setBackground(Color.WHITE);
        cmbAlumno.setBorder(bordoCampos);
        panel.add(cmbAlumno);

        JButton btnBuscar = new JButton("🔍");
        btnBuscar.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 12));
        btnBuscar.setBackground(Color.WHITE);
        btnBuscar.setBorder(bordoCampos);
        btnBuscar.setBounds(672, 122, 38, 32);
        btnBuscar.setFocusPainted(false);
        btnBuscar.setToolTipText("Ver pagos anteriores de este alumno");
        btnBuscar.addActionListener(e -> {
            AlumnoItem a = (AlumnoItem) cmbAlumno.getSelectedItem();
            mostrarPagos(a == null ? null : a.id);
        });
        panel.add(btnBuscar);

        JLabel lblMetodo = new JLabel("Método pago:");
        lblMetodo.setFont(fuenteEtiqueta);
        lblMetodo.setBounds(65, 180, 105, 25);
        panel.add(lblMetodo);

        cmbMetodoPago = new JComboBox<>(METODOS);
        cmbMetodoPago.setBounds(175, 177, 535, 32);
        cmbMetodoPago.setBackground(Color.WHITE);
        cmbMetodoPago.setBorder(bordoCampos);
        panel.add(cmbMetodoPago);

        JLabel lblMonto = new JLabel("Monto:");
        lblMonto.setFont(fuenteEtiqueta);
        lblMonto.setBounds(110, 235, 55, 25);
        panel.add(lblMonto);

        txtMonto = new JTextField();
        txtMonto.setBounds(175, 232, 535, 32);
        txtMonto.setBorder(bordoCampos);
        txtMonto.setMargin(new Insets(2, 20, 2, 2));
        panel.add(txtMonto);

        JLabel lblPesos = new JLabel("$");
        lblPesos.setFont(new Font("Arial", Font.BOLD, 14));
        lblPesos.setBounds(183, 232, 20, 32);
        panel.add(lblPesos);
        panel.setComponentZOrder(lblPesos, 0); 

        JLabel lblFecha = new JLabel("Fecha:");
        lblFecha.setFont(fuenteEtiqueta);
        lblFecha.setBounds(110, 290, 55, 25);
        panel.add(lblFecha);

        txtFecha = new JTextField();
        txtFecha.setBounds(175, 287, 120, 32);
        txtFecha.setBorder(bordoCampos);
        txtFecha.setText(LocalDate.now().format(FORMATO));
        panel.add(txtFecha);

        JButton btnCalendario = new JButton("📅");
        btnCalendario.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 12));
        btnCalendario.setBackground(Color.WHITE);
        btnCalendario.setBorder(bordoCampos);
        btnCalendario.setBounds(302, 287, 45, 32);
        btnCalendario.setFocusPainted(false);
        btnCalendario.setToolTipText("Colocar fecha actual");
        btnCalendario.addActionListener(e -> txtFecha.setText(LocalDate.now().format(FORMATO)));
        panel.add(btnCalendario);

        JLabel lblMes = new JLabel("Mes:");
        lblMes.setFont(fuenteEtiqueta);
        lblMes.setBounds(365, 290, 40, 25);
        panel.add(lblMes);

        cmbMes = new JComboBox<>(MESES);
        cmbMes.setBounds(405, 287, 150, 32);
        cmbMes.setBackground(Color.WHITE);
        cmbMes.setBorder(bordoCampos);
        cmbMes.setSelectedIndex(LocalDate.now().getMonthValue() - 1);
        panel.add(cmbMes);

        JLabel lblAnio = new JLabel("Año:");
        lblAnio.setFont(fuenteEtiqueta);
        lblAnio.setBounds(575, 290, 40, 25);
        panel.add(lblAnio);

        txtAnio = new JTextField();
        txtAnio.setBounds(615, 287, 95, 32);
        txtAnio.setBorder(bordoCampos);
        txtAnio.setText(String.valueOf(LocalDate.now().getYear()));
        panel.add(txtAnio);

        JButton btnRegistrar = new JButton("Registrar");
        btnRegistrar.setFont(new Font("Arial", Font.BOLD, 13));
        btnRegistrar.setBackground(Color.WHITE);
        btnRegistrar.setBorder(new LineBorder(new Color(0, 0, 0)));
        btnRegistrar.setFocusPainted(false);
        btnRegistrar.setBounds(380, 375, 105, 35);
        btnRegistrar.addActionListener(e -> registrarPago());
        panel.add(btnRegistrar);

        JButton btnConsultar = new JButton("Ver pagos");
        btnConsultar.setFont(new Font("Arial", Font.BOLD, 13));
        btnConsultar.setBackground(Color.WHITE);
        btnConsultar.setBorder(new LineBorder(new Color(0, 0, 0)));
        btnConsultar.setFocusPainted(false);
        btnConsultar.setBounds(498, 375, 105, 35);
        btnConsultar.addActionListener(e -> mostrarPagos());
        panel.add(btnConsultar);

        JButton btnCancelar = new JButton("Cancelar");
        btnCancelar.setFont(new Font("Arial", Font.BOLD, 13));
        btnCancelar.setBackground(Color.WHITE);
        btnCancelar.setBorder(new LineBorder(new Color(0, 0, 0)));
        btnCancelar.setFocusPainted(false);
        btnCancelar.setBounds(615, 375, 95, 35);
        btnCancelar.addActionListener(e -> limpiarCampos());
        panel.add(btnCancelar);

        try {
            for (AlumnoItem a : cargarAlumnos()) {
                cmbAlumno.addItem(a);
            }
        } catch (SQLException ex) {
            errorBD("No se pudieron cargar los alumnos", ex);
        }
    }

    private List<AlumnoItem> cargarAlumnos() throws SQLException {
        List<AlumnoItem> lista = new ArrayList<>();
        String sql = "SELECT id_alumno, nombre FROM Alumno ORDER BY nombre";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(new AlumnoItem(rs.getInt("id_alumno"), rs.getString("nombre")));
            }
        }
        return lista;
    }

    private List<Object[]> cargarPagos(Integer idAlumno) throws SQLException {
        List<Object[]> pagos = new ArrayList<>();
        
        String sql = "SELECT c.id_comprobante, c.id_alumno, c.mes, c.`año`, c.numero_comprobante, "
                + "a.nombre, c.metodo_pago, c.monto_total, c.fecha_pago "
                + "FROM Comprobante_pago c JOIN Alumno a ON a.id_alumno = c.id_alumno "
                + (idAlumno != null ? "WHERE c.id_alumno = ? " : "")
                + "ORDER BY c.fecha_pago DESC, c.id_comprobante DESC";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            if (idAlumno != null) {
                ps.setInt(1, idAlumno);
            }

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    int mes = rs.getInt("mes");
                    int anio = rs.getInt("año");
                    pagos.add(new Object[] {
                        rs.getInt("id_comprobante"),
                        rs.getInt("id_alumno"),
                        mes,
                        anio,
                        rs.getString("numero_comprobante"),
                        rs.getString("nombre"),
                        MESES[mes - 1] + " " + anio,
                        rs.getString("metodo_pago"),
                        rs.getBigDecimal("monto_total").toPlainString(),
                        rs.getDate("fecha_pago").toLocalDate().format(FORMATO)
                    });
                }
            }
        }
        return pagos;
    }

    private void errorBD(String titulo, SQLException ex) {
        JOptionPane.showMessageDialog(this,
                titulo + ":\n" + ex.getMessage(),
                "Error de base de datos", JOptionPane.ERROR_MESSAGE);
    }

    private BigDecimal leerMonto(String texto) {
        try {
            BigDecimal monto = new BigDecimal(normalizarMonto(texto));
            if (monto.compareTo(BigDecimal.ZERO) <= 0 || monto.scale() > 2
                    || monto.compareTo(MONTO_MAXIMO) > 0) {
                return null;
            }
            return monto;
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    private LocalDate leerFecha(String texto) {
        try {
            return LocalDate.parse(texto, FORMATO);
        } catch (DateTimeParseException ex) {
            return null;
        }
    }

    private int leerAnio(String texto) {
        try {
            int anio = Integer.parseInt(texto.trim());
            return (anio >= 2000 && anio <= 2100) ? anio : -1;
        } catch (NumberFormatException ex) {
            return -1;
        }
    }

    private String normalizarMonto(String texto) {
        String cantidad = texto.replace("$", "").replace(" ", "");
        if (cantidad.contains(",") && cantidad.contains(".")) {
            if (cantidad.lastIndexOf(',') > cantidad.lastIndexOf('.')) {
                cantidad = cantidad.replace(".", "").replace(',', '.');
            } else {
                cantidad = cantidad.replace(",", "");
            }
        } else if (cantidad.contains(",")) {
            cantidad = cantidad.replace(',', '.');
        }
        return cantidad;
    }

    private void registrarPago() {
        if (!Sesion.haySesion()) {
            JOptionPane.showMessageDialog(this, "Inicia sesión desde el Login para poder registrar pagos.", "Sin sesión", JOptionPane.WARNING_MESSAGE);
            return;
        }

        AlumnoItem alumno = (AlumnoItem) cmbAlumno.getSelectedItem();
        String metodoPago = (String) cmbMetodoPago.getSelectedItem();
        String montoTexto = txtMonto.getText().trim();
        String fechaTexto = txtFecha.getText().trim();

        if (alumno == null) {
            JOptionPane.showMessageDialog(this,
                    "No hay alumnos registrados. Primero registra al alumno.",
                    "Sin alumnos", JOptionPane.WARNING_MESSAGE);
            return;
        }
        if (montoTexto.isEmpty() || fechaTexto.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Por favor, complete todos los campos obligatorios.",
                    "Campos incompletos", JOptionPane.WARNING_MESSAGE);
            return;
        }

        BigDecimal monto = leerMonto(montoTexto);
        if (monto == null) {
            JOptionPane.showMessageDialog(this, "Ingrese un monto válido y mayor que cero.\nEjemplo: 250.00",
                    "Monto incorrecto", JOptionPane.WARNING_MESSAGE);
            txtMonto.requestFocus();
            return;
        }

        LocalDate fecha = leerFecha(fechaTexto);
        if (fecha == null) {
            JOptionPane.showMessageDialog(this, "La fecha debe ser válida y usar dd/MM/aaaa.",
                    "Fecha incorrecta", JOptionPane.WARNING_MESSAGE);
            txtFecha.requestFocus();
            return;
        }

        int mes = cmbMes.getSelectedIndex() + 1;
        int anio = leerAnio(txtAnio.getText());
        if (anio == -1) {
            JOptionPane.showMessageDialog(this, "Escribe un año válido (por ejemplo 2026).",
                    "Año incorrecto", JOptionPane.WARNING_MESSAGE);
            txtAnio.requestFocus();
            return;
        }
        
        String numeroComprobante = "CP-" + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmssSSS"));

        String sql = "INSERT INTO Comprobante_pago "
                + "(numero_comprobante, mes, `año`, fecha_pago, metodo_pago, monto_total, id_tutor, id_alumno, id_secretaria) "
                + "SELECT ?, ?, ?, ?, ?, ?, id_tutor, id_alumno, ? FROM Alumno WHERE id_alumno = ?";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, numeroComprobante);
            ps.setInt(2, mes);
            ps.setInt(3, anio);
            ps.setDate(4, Date.valueOf(fecha));
            ps.setString(5, metodoPago);
            ps.setBigDecimal(6, monto);
            ps.setInt(7, Sesion.idSecretaria);
            ps.setInt(8, alumno.id);
            ps.executeUpdate();

        } catch (SQLException ex) {
            if (ex.getErrorCode() == 1062) {
                JOptionPane.showMessageDialog(this,
                        alumno.nombre + " ya tiene registrado el pago de " + MESES[mes - 1] + " " + anio + ".",
                        "Pago duplicado", JOptionPane.WARNING_MESSAGE);
            } else {
                errorBD("No se pudo guardar el pago", ex);
            }
            return;
        }

        JOptionPane.showMessageDialog(this,
                "¡Pago registrado y guardado correctamente!\n\n"
                + "Comprobante: " + numeroComprobante + "\n"
                + "Alumno: " + alumno.nombre + "\n"
                + "Mes: " + MESES[mes - 1] + " " + anio + "\n"
                + "Método de Pago: " + metodoPago + "\n"
                + "Monto: $" + monto.toPlainString() + "\n"
                + "Fecha: " + fecha.format(FORMATO),
                "Registro exitoso", JOptionPane.INFORMATION_MESSAGE);

        limpiarCampos();
    }

    public void mostrarPagos() {
        mostrarPagos(null);
    }

    private void mostrarPagos(Integer idAlumno) {
        List<Object[]> pagos;
        try {
            pagos = cargarPagos(idAlumno);
        } catch (SQLException ex) {
            errorBD("No se pudieron leer los pagos", ex);
            return;
        }

        String[] columnas = {"ID", "ID alumno", "Mes", "Año",
                "Comprobante", "Alumno", "Periodo", "Método Pago", "Monto", "Fecha"};
        DefaultTableModel modelo = new DefaultTableModel(columnas, 0) {
            private static final long serialVersionUID = 1L;

            @Override
            public boolean isCellEditable(int fila, int columna) {
                return false;
            }
        };

        for (Object[] pago : pagos) {
            modelo.addRow(pago);
        }

        JTable tabla = new JTable(modelo);
        tabla.setRowHeight(25);
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        for (int i = 0; i < 4; i++) {
            tabla.removeColumn(tabla.getColumnModel().getColumn(0));
        }

        TableRowSorter<DefaultTableModel> ordenador = new TableRowSorter<>(modelo);
        tabla.setRowSorter(ordenador);

        JTextField filtro = new JTextField();
        filtro.getDocument().addDocumentListener(new DocumentListener() {
            private void filtrar() {
                String texto = filtro.getText().trim();

                if (texto.isEmpty()) {
                    ordenador.setRowFilter(null);
                } else {
                    ordenador.setRowFilter(
                            RowFilter.regexFilter(
                                    "(?i)" + java.util.regex.Pattern.quote(texto)));
                }
            }

            @Override public void insertUpdate(DocumentEvent e) { filtrar(); }
            @Override public void removeUpdate(DocumentEvent e) { filtrar(); }
            @Override public void changedUpdate(DocumentEvent e) { filtrar(); }
        });

        JPanel superior = new JPanel(new BorderLayout(8, 0));
        superior.setBackground(Color.WHITE);
        superior.add(new JLabel("Buscar:"), BorderLayout.WEST);
        superior.add(filtro, BorderLayout.CENTER);

        JButton btnModificar = new JButton("Modificar");
        btnModificar.setBackground(Color.WHITE);
        btnModificar.setBorder(new LineBorder(Color.BLACK, 1));
        btnModificar.addActionListener(e -> {
            int filaVista = tabla.getSelectedRow();
            if (filaVista == -1) {
                JOptionPane.showMessageDialog(tabla, "Selecciona un pago para modificar.");
                return;
            }
            editarPago(modelo, tabla.convertRowIndexToModel(filaVista));
        });

        JButton btnEliminar = new JButton("Eliminar");
        btnEliminar.setBackground(Color.WHITE);
        btnEliminar.setBorder(new LineBorder(Color.BLACK, 1));
        btnEliminar.addActionListener(e -> {
            int filaVista = tabla.getSelectedRow();
            if (filaVista == -1) {
                JOptionPane.showMessageDialog(tabla, "Selecciona un pago para eliminar.");
                return;
            }
            eliminarPago(modelo, tabla.convertRowIndexToModel(filaVista));
        });

        JButton btnCerrar = new JButton("Cerrar");
        btnCerrar.setBackground(Color.WHITE);
        btnCerrar.setBorder(new LineBorder(Color.BLACK, 1));

        JDialog dialogo = new JDialog(this, "Pagos registrados", true);
        btnCerrar.addActionListener(e -> dialogo.dispose());

        JPanel inferior = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        inferior.setBackground(Color.WHITE);
        inferior.add(btnModificar);
        inferior.add(btnEliminar);
        inferior.add(btnCerrar);

        dialogo.getContentPane().setBackground(Color.WHITE);
        dialogo.getContentPane().setLayout(new BorderLayout(10, 10));
        dialogo.getContentPane().add(superior, BorderLayout.NORTH);
        dialogo.getContentPane().add(new JScrollPane(tabla), BorderLayout.CENTER);
        dialogo.getContentPane().add(inferior, BorderLayout.SOUTH);
        dialogo.setSize(850, 400);
        dialogo.setLocationRelativeTo(this);
        dialogo.setVisible(true);
    }
    
    private static final int C_ID = 0, C_ID_ALUMNO = 1, C_MES = 2, C_ANIO = 3, C_COMPROBANTE = 4, C_ALUMNO = 5, C_PERIODO = 6, C_METODO = 7, C_MONTO = 8, C_FECHA = 9;

    private void editarPago(DefaultTableModel modelo, int fila) {
        int idComprobante = (Integer) modelo.getValueAt(fila, C_ID);
        int idAlumnoActual = (Integer) modelo.getValueAt(fila, C_ID_ALUMNO);

        List<AlumnoItem> alumnos;
        try {
            alumnos = cargarAlumnos();
        } catch (SQLException ex) {
            errorBD("No se pudieron cargar los alumnos", ex);
            return;
        }

        JComboBox<AlumnoItem> alumno = new JComboBox<>();
        for (AlumnoItem a : alumnos) {
            alumno.addItem(a);
            if (a.id == idAlumnoActual) {
                alumno.setSelectedItem(a);
            }
        }
        JComboBox<String> metodo = new JComboBox<>(METODOS);
        metodo.setSelectedItem(modelo.getValueAt(fila, C_METODO).toString());
        JTextField monto = new JTextField(modelo.getValueAt(fila, C_MONTO).toString());
        JTextField fecha = new JTextField(modelo.getValueAt(fila, C_FECHA).toString());
        JComboBox<String> mes = new JComboBox<>(MESES);
        mes.setSelectedIndex((Integer) modelo.getValueAt(fila, C_MES) - 1);
        JTextField anio = new JTextField(modelo.getValueAt(fila, C_ANIO).toString());

        JPanel formulario = new JPanel(new GridLayout(6, 2, 8, 8));
        formulario.add(new JLabel("Alumno:"));
        formulario.add(alumno);
        formulario.add(new JLabel("Método pago:"));
        formulario.add(metodo);
        formulario.add(new JLabel("Monto:"));
        formulario.add(monto);
        formulario.add(new JLabel("Fecha (dd/MM/aaaa):"));
        formulario.add(fecha);
        formulario.add(new JLabel("Mes:"));
        formulario.add(mes);
        formulario.add(new JLabel("Año:"));
        formulario.add(anio);

        int resultado = JOptionPane.showConfirmDialog(
                this, formulario, "Modificar pago",
                JOptionPane.OK_CANCEL_OPTION,
                JOptionPane.PLAIN_MESSAGE);

        if (resultado != JOptionPane.OK_OPTION) {
            return;
        }

        AlumnoItem nuevoAlumno = (AlumnoItem) alumno.getSelectedItem();
        String nuevoMetodo = (String) metodo.getSelectedItem();
        BigDecimal nuevoMonto = leerMonto(monto.getText().trim());
        LocalDate nuevaFecha = leerFecha(fecha.getText().trim());
        int nuevoMes = mes.getSelectedIndex() + 1;
        int nuevoAnio = leerAnio(anio.getText());

        if (nuevoAlumno == null) {
            JOptionPane.showMessageDialog(this, "Selecciona un alumno.");
            return;
        }
        if (nuevoMonto == null) {
            JOptionPane.showMessageDialog(this, "El monto debe ser válido, mayor que cero y tener máximo dos decimales.");
            return;
        }
        if (nuevaFecha == null) {
            JOptionPane.showMessageDialog(this, "La fecha debe ser válida y usar dd/MM/aaaa.");
            return;
        }
        if (nuevoAnio == -1) {
            JOptionPane.showMessageDialog(this, "Escribe un año válido (por ejemplo 2026).");
            return;
        }
        
        String sql = "UPDATE Comprobante_pago SET id_alumno = ?, "
                + "id_tutor = (SELECT id_tutor FROM Alumno WHERE id_alumno = ?), "
                + "metodo_pago = ?, monto_total = ?, fecha_pago = ?, mes = ?, `año` = ? "
                + "WHERE id_comprobante = ?";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, nuevoAlumno.id);
            ps.setInt(2, nuevoAlumno.id);
            ps.setString(3, nuevoMetodo);
            ps.setBigDecimal(4, nuevoMonto);
            ps.setDate(5, Date.valueOf(nuevaFecha));
            ps.setInt(6, nuevoMes);
            ps.setInt(7, nuevoAnio);
            ps.setInt(8, idComprobante);
            ps.executeUpdate();

        } catch (SQLException ex) {
            if (ex.getErrorCode() == 1062) {
                JOptionPane.showMessageDialog(this,
                        nuevoAlumno.nombre + " ya tiene registrado el pago de " + MESES[nuevoMes - 1] + " " + nuevoAnio + ".",
                        "Pago duplicado", JOptionPane.WARNING_MESSAGE);
            } else {
                errorBD("No se pudo guardar el cambio", ex);
            }
            return;
        }
        modelo.setValueAt(nuevoAlumno.id, fila, C_ID_ALUMNO);
        modelo.setValueAt(nuevoMes, fila, C_MES);
        modelo.setValueAt(nuevoAnio, fila, C_ANIO);
        modelo.setValueAt(nuevoAlumno.nombre, fila, C_ALUMNO);
        modelo.setValueAt(MESES[nuevoMes - 1] + " " + nuevoAnio, fila, C_PERIODO);
        modelo.setValueAt(nuevoMetodo, fila, C_METODO);
        modelo.setValueAt(nuevoMonto.toPlainString(), fila, C_MONTO);
        modelo.setValueAt(nuevaFecha.format(FORMATO), fila, C_FECHA);

        JOptionPane.showMessageDialog(this, "El pago se modificó correctamente.");
    }

    private void eliminarPago(DefaultTableModel modelo, int fila) {
        int idComprobante = (Integer) modelo.getValueAt(fila, C_ID);
        String nombre = modelo.getValueAt(fila, C_ALUMNO).toString();
        String periodo = modelo.getValueAt(fila, C_PERIODO).toString();

        int respuesta = JOptionPane.showConfirmDialog(
                this,
                "¿Deseas eliminar este pago?\n\nAlumno: " + nombre + "\nPeriodo: " + periodo,
                "Confirmar eliminación",
                JOptionPane.YES_NO_OPTION,
                JOptionPane.WARNING_MESSAGE);

        if (respuesta != JOptionPane.YES_OPTION) {
            return;
        }

        String sql = "DELETE FROM Comprobante_pago WHERE id_comprobante = ?";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, idComprobante);
            ps.executeUpdate();

        } catch (SQLException ex) {
            errorBD("No se pudo eliminar el registro", ex);
            return;
        }

        modelo.removeRow(fila);
        JOptionPane.showMessageDialog(this, "El pago se eliminó correctamente.");
    }

    private void limpiarCampos() {
        if (cmbAlumno.getItemCount() > 0) {
            cmbAlumno.setSelectedIndex(0);
        }
        cmbMetodoPago.setSelectedIndex(0);
        txtMonto.setText("");
        txtFecha.setText(LocalDate.now().format(FORMATO));
        cmbMes.setSelectedIndex(LocalDate.now().getMonthValue() - 1);
        txtAnio.setText(String.valueOf(LocalDate.now().getYear()));
        cmbAlumno.requestFocus();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ex) {
            }

            new VentanaPagos().setVisible(true);
        });
    }
}
