package poo.intermenu;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

public class Menuprincipal extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Menuprincipal frame = new Menuprincipal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public Menuprincipal() {
		setTitle("Menú principal");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 793, 488);
		setLocationRelativeTo(null);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JPanel panel = new JPanel();
		panel.setBorder(new LineBorder(new Color(0, 0, 0)));
		panel.setBounds(10, 10, 759, 78);
		contentPane.add(panel);
		panel.setLayout(null);

		JLabel lblSecretaria = new JLabel("Secretaria");
		lblSecretaria.setFont(new Font("Arial", Font.BOLD, 13));
		lblSecretaria.setBounds(563, 30, 92, 24);
		if (Sesion.nombreSecretaria != null) {
			lblSecretaria.setToolTipText(Sesion.nombreSecretaria);
		}
		panel.add(lblSecretaria);

		JLabel lblCerrar = new JLabel("Cerrar Sesión");
		lblCerrar.setFont(new Font("Arial", Font.BOLD, 13));
		lblCerrar.setBounds(68, 16, 92, 52);
		panel.add(lblCerrar);

		JButton btnCerrarSesion = new JButton("");
		btnCerrarSesion.setIcon(Imagenes.cargar("cerrar sesion.jpg", 25, 25));
		btnCerrarSesion.setBounds(10, 10, 48, 58);
		btnCerrarSesion.addActionListener(e -> {
			Sesion.cerrar();
			new Login().setVisible(true);
			dispose();
		});
		panel.add(btnCerrarSesion);

		JLabel lblUsuario = new JLabel("");
		lblUsuario.setIcon(Imagenes.cargar("usuario.png", 45, 45));
		lblUsuario.setBounds(665, 16, 57, 52);
		panel.add(lblUsuario);

		JPanel panel_1 = new JPanel();
		panel_1.setBounds(10, 98, 759, 343);
		contentPane.add(panel_1);
		panel_1.setLayout(null);

		JButton btnAlumno = new JButton("Registrar Alumno");
		btnAlumno.setFont(new Font("Arial", Font.BOLD, 12));
		btnAlumno.setBounds(10, 10, 170, 53);
		btnAlumno.addActionListener(e -> new RegistroAlumno().setVisible(true));
		panel_1.add(btnAlumno);

		JButton btnPago = new JButton("Registrar Pago");
		btnPago.setFont(new Font("Arial", Font.BOLD, 12));
		btnPago.setBounds(200, 10, 170, 53);
		btnPago.addActionListener(e -> new VentanaPagos().setVisible(true));
		panel_1.add(btnPago);

		JButton btnConsultar = new JButton("Consultar Pago");
		btnConsultar.setFont(new Font("Arial", Font.BOLD, 12));
		btnConsultar.setBounds(390, 10, 170, 53);
		btnConsultar.addActionListener(e -> {
			VentanaPagos v = new VentanaPagos();
			v.setVisible(true);
			v.mostrarPagos();
		});
		panel_1.add(btnConsultar);

		JButton btnVenta = new JButton("Registrar Venta");
		btnVenta.setFont(new Font("Arial", Font.BOLD, 12));
		btnVenta.setBounds(580, 10, 170, 53);
		btnVenta.addActionListener(e -> new RegistroVentas().setVisible(true));
		panel_1.add(btnVenta);

		JLabel lblLogo = new JLabel("");
		lblLogo.setIcon(Imagenes.cargar("logo.jpeg", 250, 250));
		lblLogo.setHorizontalAlignment(SwingConstants.CENTER);
		lblLogo.setBounds(206, 73, 361, 260);
		panel_1.add(lblLogo);
	}
}
