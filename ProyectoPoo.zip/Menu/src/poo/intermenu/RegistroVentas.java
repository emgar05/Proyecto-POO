package poo.intermenu;

import java.awt.EventQueue;
import java.awt.Font;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

public class RegistroVentas extends JFrame {

    private static final long serialVersionUID = 1L;
    private static class ClienteItem {
        final int id;
        final String nombre;

        ClienteItem(int id, String nombre) {
            this.id = id;
            this.nombre = nombre;
        }

        @Override
        public String toString() {
            return nombre;
        }
    }

    private static class ProductoItem {
        final int id;
        final String nombre;
        final BigDecimal precio;

        ProductoItem(int id, String nombre, BigDecimal precio) {
            this.id = id;
            this.nombre = nombre;
            this.precio = precio;
        }

        @Override
        public String toString() {
            return nombre;
        }
    }

    private JPanel contentPane;
    private JTextField txtCantidad;
    private JTextField txtPrecio;
    private JTextField txtTotal;
    private JComboBox<ClienteItem> comboCliente;
    private JComboBox<ProductoItem> comboProducto;
    private JButton btnAceptar;
    private JButton btnCancelar;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    RegistroVentas frame = new RegistroVentas();
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public RegistroVentas() {

        setTitle("Registro de Ventas");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 450, 330);
        setLocationRelativeTo(null);
        setResizable(false);

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblLogo = new JLabel("");
        lblLogo.setIcon(Imagenes.cargar("logo.jpeg", 40, 40));
        lblLogo.setBounds(6, 6, 45, 45);
        contentPane.add(lblLogo);

        JLabel lblTitulo = new JLabel("Registro de Ventas");
        lblTitulo.setFont(new Font("Lucida Grande", Font.PLAIN, 14));
        lblTitulo.setBounds(60, 15, 150, 16);
        contentPane.add(lblTitulo);

        JLabel lblSecretaria = new JLabel("Secretaria");
        lblSecretaria.setFont(new Font("Lucida Grande", Font.PLAIN, 14));
        lblSecretaria.setBounds(310, 15, 86, 16);
        contentPane.add(lblSecretaria);

        JLabel lblUsuario = new JLabel("");
        lblUsuario.setIcon(Imagenes.cargar("usuario.png", 35, 35));
        lblUsuario.setBounds(398, 6, 35, 35);
        contentPane.add(lblUsuario);

        JSeparator separator = new JSeparator();
        separator.setBounds(6, 50, 426, 10);
        contentPane.add(separator);

        JLabel lblCliente = new JLabel("Cliente:");
        lblCliente.setFont(new Font("Lucida Grande", Font.PLAIN, 12));
        lblCliente.setBounds(75, 75, 61, 16);
        contentPane.add(lblCliente);

        comboCliente = new JComboBox<ClienteItem>();
        comboCliente.setBounds(141, 70, 248, 27);
        contentPane.add(comboCliente);

        JLabel lblProducto = new JLabel("Producto:");
        lblProducto.setFont(new Font("Lucida Grande", Font.PLAIN, 12));
        lblProducto.setBounds(75, 115, 61, 16);
        contentPane.add(lblProducto);

        comboProducto = new JComboBox<ProductoItem>();
        comboProducto.setBounds(141, 110, 248, 27);
        contentPane.add(comboProducto);

        JLabel lblPrecio = new JLabel("Precio:");
        lblPrecio.setFont(new Font("Lucida Grande", Font.PLAIN, 12));
        lblPrecio.setBounds(75, 158, 61, 16);
        contentPane.add(lblPrecio);

        txtPrecio = new JTextField();
        txtPrecio.setBounds(120, 153, 100, 26);
        txtPrecio.setEditable(false);
        contentPane.add(txtPrecio);
        txtPrecio.setColumns(10);

        JLabel lblCantidad = new JLabel("Cantidad:");
        lblCantidad.setFont(new Font("Lucida Grande", Font.PLAIN, 12));
        lblCantidad.setBounds(245, 158, 61, 16);
        contentPane.add(lblCantidad);

        txtCantidad = new JTextField();
        txtCantidad.setBounds(310, 153, 79, 26);
        contentPane.add(txtCantidad);
        txtCantidad.setColumns(10);

        JLabel lblTotal = new JLabel("Total:");
        lblTotal.setFont(new Font("Lucida Grande", Font.PLAIN, 12));
        lblTotal.setBounds(245, 200, 61, 16);
        contentPane.add(lblTotal);

        txtTotal = new JTextField();
        txtTotal.setBounds(285, 195, 104, 26);
        txtTotal.setEditable(false);
        contentPane.add(txtTotal);
        txtTotal.setColumns(10);

        btnAceptar = new JButton("Aceptar");
        btnAceptar.setBounds(210, 245, 92, 29);
        contentPane.add(btnAceptar);

        btnCancelar = new JButton("Cancelar");
        btnCancelar.setBounds(310, 245, 89, 29);
        contentPane.add(btnCancelar);

        cargarClientes();
        cargarProductos();
        actualizarPrecio();

        comboProducto.addActionListener(e -> {
            actualizarPrecio();
            calcularTotal();
        });

        txtCantidad.getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void insertUpdate(DocumentEvent e) { calcularTotal(); }

            @Override
            public void removeUpdate(DocumentEvent e) { calcularTotal(); }

            @Override
            public void changedUpdate(DocumentEvent e) { calcularTotal(); }
        });

        btnAceptar.addActionListener(e -> registrarVenta());

        btnCancelar.addActionListener(e -> {
            txtCantidad.setText("");
            txtTotal.setText("");
            if (comboProducto.getItemCount() > 0) {
                comboProducto.setSelectedIndex(0);
            }
            actualizarPrecio();
        });
    }

    private void cargarClientes() {
        List<ClienteItem> lista = new ArrayList<>();
        String sql = "SELECT id_cliente, nombre FROM Cliente ORDER BY nombre";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(new ClienteItem(rs.getInt("id_cliente"), rs.getString("nombre")));
            }

        } catch (SQLException ex) {
            errorBD("No se pudieron cargar los clientes", ex);
        }

        for (ClienteItem c : lista) {
            comboCliente.addItem(c);
        }
    }

    private void cargarProductos() {
        List<ProductoItem> lista = new ArrayList<>();
        String sql = "SELECT id_producto, nombre, precio FROM Producto ORDER BY nombre";

        try (Connection con = Conexion.getConexion();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(new ProductoItem(rs.getInt("id_producto"),
                        rs.getString("nombre"), rs.getBigDecimal("precio")));
            }

        } catch (SQLException ex) {
            errorBD("No se pudieron cargar los productos", ex);
        }

        for (ProductoItem p : lista) {
            comboProducto.addItem(p);
        }
    }

    private void errorBD(String titulo, SQLException ex) {
        JOptionPane.showMessageDialog(this,
                titulo + ":\n" + ex.getMessage(),
                "Error de base de datos", JOptionPane.ERROR_MESSAGE);
    }

    private void actualizarPrecio() {
        ProductoItem p = (ProductoItem) comboProducto.getSelectedItem();
        txtPrecio.setText(p == null ? "" : "$" + p.precio.toPlainString());
    }

    private void calcularTotal() {
        ProductoItem p = (ProductoItem) comboProducto.getSelectedItem();
        if (p == null) {
            txtTotal.setText("");
            return;
        }
        try {
            int cantidad = Integer.parseInt(txtCantidad.getText().trim());
            if (cantidad > 0) {
                txtTotal.setText(p.precio.multiply(BigDecimal.valueOf(cantidad)).setScale(2).toPlainString());
            } else {
                txtTotal.setText("");
            }
        } catch (NumberFormatException e) {
            txtTotal.setText("");
        }
    }

    private void registrarVenta() {
        if (!Sesion.haySesion()) {
            JOptionPane.showMessageDialog(this,
                    "Inicia sesión desde el Login para poder registrar ventas.",
                    "Sin sesión", JOptionPane.WARNING_MESSAGE);
            return;
        }

        ClienteItem cliente = (ClienteItem) comboCliente.getSelectedItem();
        ProductoItem p = (ProductoItem) comboProducto.getSelectedItem();
        if (cliente == null || p == null) {
            JOptionPane.showMessageDialog(this,
                    "Faltan clientes o productos en la base de datos.",
                    "Sin datos", JOptionPane.WARNING_MESSAGE);
            return;
        }

        int cantidad;
        try {
            cantidad = Integer.parseInt(txtCantidad.getText().trim());
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Ingresa una cantidad entera válida.",
                    "Datos incorrectos", JOptionPane.WARNING_MESSAGE);
            txtCantidad.requestFocus();
            return;
        }
        if (cantidad <= 0 || cantidad > 1000) {
            JOptionPane.showMessageDialog(this, "La cantidad debe estar entre 1 y 1000.",
                    "Datos incorrectos", JOptionPane.WARNING_MESSAGE);
            txtCantidad.requestFocus();
            return;
        }

        BigDecimal total = p.precio.multiply(BigDecimal.valueOf(cantidad)).setScale(2);

        Connection con = null;
        try {
            con = Conexion.getConexion();
            con.setAutoCommit(false);

            int noVenta;
            String sqlCompra = "INSERT INTO Compra (fecha, total, id_cliente, id_secretaria) VALUES (NOW(), ?, ?, ?)";
            try (PreparedStatement ps = con.prepareStatement(sqlCompra, Statement.RETURN_GENERATED_KEYS)) {
                ps.setBigDecimal(1, total);
                ps.setInt(2, cliente.id);
                ps.setInt(3, Sesion.idSecretaria);
                ps.executeUpdate();
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    rs.next();
                    noVenta = rs.getInt(1);
                }
            }

            String sqlDetalle = "INSERT INTO Compra_producto (no_venta, id_producto, cantidad) VALUES (?, ?, ?)";
            try (PreparedStatement ps = con.prepareStatement(sqlDetalle)) {
                ps.setInt(1, noVenta);
                ps.setInt(2, p.id);
                ps.setInt(3, cantidad);
                ps.executeUpdate();
            }

            con.commit();

            JOptionPane.showMessageDialog(this,
                    "Venta registrada correctamente.\n\n"
                    + "Venta No. " + noVenta
                    + "\nCliente: " + cliente.nombre
                    + "\nProducto: " + p.nombre
                    + "\nCantidad: " + cantidad
                    + "\nPrecio unitario: $" + p.precio.toPlainString()
                    + "\nTotal: $" + total.toPlainString(),
                    "Registro de venta", JOptionPane.INFORMATION_MESSAGE);

            txtCantidad.setText("");
            txtTotal.setText("");
            txtCantidad.requestFocus();

        } catch (SQLException ex) {
            if (con != null) {
                try { con.rollback(); } catch (SQLException ignorar) { }
            }
            errorBD("No se pudo guardar la venta", ex);
        } finally {
            if (con != null) {
                try { con.close(); } catch (SQLException ignorar) { }
            }
        }
    }
}
